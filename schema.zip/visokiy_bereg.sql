-- phpMyAdmin SQL Dump
-- version 4.2.5
-- http://www.phpmyadmin.net
--
-- Хост: localhost
-- Время создания: Апр 06 2015 г., 17:22
-- Версия сервера: 5.5.25
-- Версия PHP: 5.5.9

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- База данных: `visokiy_bereg`
--

-- --------------------------------------------------------

--
-- Структура таблицы `actions`
--

DROP TABLE IF EXISTS `actions`;
CREATE TABLE IF NOT EXISTS `actions` (
`id` int(10) unsigned NOT NULL,
  `group_id` int(10) unsigned DEFAULT NULL,
  `module` varchar(32) COLLATE utf8_unicode_ci DEFAULT NULL,
  `action` varchar(32) COLLATE utf8_unicode_ci DEFAULT NULL,
  `status` int(10) unsigned NOT NULL DEFAULT '0'
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=44 ;

--
-- Дамп данных таблицы `actions`
--

INSERT INTO `actions` (`id`, `group_id`, `module`, `action`, `status`) VALUES
(16, 2, 'dictionaries', 'dicval_view', 1),
(17, 2, 'dictionaries', 'dicval_create', 1),
(18, 2, 'dictionaries', 'dicval_edit', 1),
(19, 2, 'dictionaries', 'dicval_delete', 1),
(20, 2, 'dictionaries', 'dicval_entity_view', 1),
(21, 2, 'galleries', 'create', 1),
(22, 2, 'galleries', 'edit', 1),
(23, 2, 'galleries', 'delete', 1),
(24, 2, 'news', 'view', 1),
(25, 2, 'news', 'create', 1),
(26, 2, 'news', 'edit', 1),
(27, 2, 'news', 'delete', 1),
(28, 2, 'pages', 'view', 1),
(29, 2, 'pages', 'create', 1),
(30, 2, 'pages', 'edit', 1),
(31, 2, 'pages', 'delete', 1),
(32, 2, 'pages', 'advanced', 1),
(33, 2, 'pages', 'page_restore', 1),
(34, 2, 'seo', 'edit', 1),
(35, 3, 'news', 'view', 1),
(36, 3, 'news', 'create', 1),
(37, 3, 'news', 'edit', 1),
(38, 3, 'news', 'delete', 1),
(39, 3, 'pages', 'view', 1),
(40, 3, 'pages', 'create', 1),
(41, 3, 'pages', 'edit', 1),
(42, 3, 'pages', 'delete', 1),
(43, 3, 'seo', 'edit', 1);

-- --------------------------------------------------------

--
-- Структура таблицы `dictionary`
--

DROP TABLE IF EXISTS `dictionary`;
CREATE TABLE IF NOT EXISTS `dictionary` (
`id` int(10) unsigned NOT NULL,
  `slug` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `entity` tinyint(1) unsigned DEFAULT NULL,
  `icon_class` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `hide_slug` tinyint(1) unsigned DEFAULT NULL,
  `make_slug_from_name` tinyint(1) unsigned DEFAULT NULL,
  `name_title` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `pagination` int(10) unsigned NOT NULL DEFAULT '0',
  `view_access` smallint(5) unsigned DEFAULT NULL,
  `sort_by` varchar(64) COLLATE utf8_unicode_ci DEFAULT NULL,
  `sort_order_reverse` smallint(5) unsigned NOT NULL DEFAULT '0',
  `sortable` smallint(5) unsigned NOT NULL DEFAULT '1',
  `order` int(10) unsigned DEFAULT NULL,
  `settings` longtext COLLATE utf8_unicode_ci,
  `created_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Структура таблицы `dictionary_fields_values`
--

DROP TABLE IF EXISTS `dictionary_fields_values`;
CREATE TABLE IF NOT EXISTS `dictionary_fields_values` (
`id` int(10) unsigned NOT NULL,
  `dicval_id` int(10) unsigned DEFAULT NULL,
  `language` varchar(16) COLLATE utf8_unicode_ci DEFAULT NULL,
  `key` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `value` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Структура таблицы `dictionary_textfields_values`
--

DROP TABLE IF EXISTS `dictionary_textfields_values`;
CREATE TABLE IF NOT EXISTS `dictionary_textfields_values` (
`id` int(10) unsigned NOT NULL,
  `dicval_id` int(10) unsigned DEFAULT NULL,
  `language` varchar(16) COLLATE utf8_unicode_ci DEFAULT NULL,
  `key` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `value` longtext COLLATE utf8_unicode_ci,
  `created_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Структура таблицы `dictionary_values`
--

DROP TABLE IF EXISTS `dictionary_values`;
CREATE TABLE IF NOT EXISTS `dictionary_values` (
`id` int(10) unsigned NOT NULL,
  `version_of` int(10) unsigned DEFAULT NULL,
  `dic_id` int(10) unsigned DEFAULT NULL,
  `slug` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `order` int(10) unsigned DEFAULT NULL,
  `lft` int(10) unsigned DEFAULT NULL,
  `rgt` int(10) unsigned DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Структура таблицы `dictionary_values_meta`
--

DROP TABLE IF EXISTS `dictionary_values_meta`;
CREATE TABLE IF NOT EXISTS `dictionary_values_meta` (
`id` int(10) unsigned NOT NULL,
  `dicval_id` int(10) unsigned DEFAULT NULL,
  `language` varchar(16) COLLATE utf8_unicode_ci DEFAULT NULL,
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Структура таблицы `dictionary_values_rel`
--

DROP TABLE IF EXISTS `dictionary_values_rel`;
CREATE TABLE IF NOT EXISTS `dictionary_values_rel` (
  `dicval_parent_id` int(10) unsigned NOT NULL DEFAULT '0',
  `dicval_child_id` int(10) unsigned NOT NULL DEFAULT '0',
  `dicval_parent_dic_id` int(10) unsigned DEFAULT NULL,
  `dicval_child_dic_id` int(10) unsigned DEFAULT NULL,
  `dicval_parent_field` varchar(256) COLLATE utf8_unicode_ci DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Структура таблицы `galleries`
--

DROP TABLE IF EXISTS `galleries`;
CREATE TABLE IF NOT EXISTS `galleries` (
`id` int(10) unsigned NOT NULL,
  `name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `settings` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Структура таблицы `groups`
--

DROP TABLE IF EXISTS `groups`;
CREATE TABLE IF NOT EXISTS `groups` (
`id` int(10) unsigned NOT NULL,
  `name` varchar(20) COLLATE utf8_unicode_ci NOT NULL,
  `desc` varchar(20) COLLATE utf8_unicode_ci NOT NULL,
  `dashboard` varchar(20) COLLATE utf8_unicode_ci NOT NULL,
  `start_url` varchar(256) COLLATE utf8_unicode_ci NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00'
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=4 ;

--
-- Дамп данных таблицы `groups`
--

INSERT INTO `groups` (`id`, `name`, `desc`, `dashboard`, `start_url`, `created_at`, `updated_at`) VALUES
(1, 'developer', 'Разработчики', 'admin', '', '2015-04-06 08:51:31', '2015-04-06 08:51:31'),
(2, 'admin', 'Администраторы', 'admin', '', '2015-04-06 08:51:31', '2015-04-06 08:56:51'),
(3, 'moderator', 'Модераторы', 'admin', '', '2015-04-06 08:51:31', '2015-04-06 08:57:38');

-- --------------------------------------------------------

--
-- Структура таблицы `migrations`
--

DROP TABLE IF EXISTS `migrations`;
CREATE TABLE IF NOT EXISTS `migrations` (
  `migration` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `batch` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Дамп данных таблицы `migrations`
--

INSERT INTO `migrations` (`migration`, `batch`) VALUES
('2014_01_01_100000_create_groups_table', 1),
('2014_01_01_100010_create_users_table', 1),
('2014_01_01_100020_create_modules_table', 1),
('2014_01_01_100030_create_actions_table', 1),
('2014_01_01_100040_create_session_table', 1),
('2014_01_01_100050_create_settings_table', 1),
('2014_01_01_100051_create_storages_table', 1),
('2014_01_01_100060_create_pages_tables', 1),
('2014_01_01_100080_create_galleries_table', 1),
('2014_01_01_100090_create_photos_table', 1),
('2014_01_01_100100_create_rel_mod_gallery_table', 1),
('2014_01_01_100110_create_seo_table', 1),
('2014_07_03_161130_create_dics_tables', 1),
('2014_09_02_161130_create_uploads_tables', 1);

-- --------------------------------------------------------

--
-- Структура таблицы `modules`
--

DROP TABLE IF EXISTS `modules`;
CREATE TABLE IF NOT EXISTS `modules` (
`id` int(10) unsigned NOT NULL,
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `on` tinyint(1) NOT NULL DEFAULT '0',
  `order` tinyint(1) NOT NULL DEFAULT '0',
  `created_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00'
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=9 ;

--
-- Дамп данных таблицы `modules`
--

INSERT INTO `modules` (`id`, `name`, `on`, `order`, `created_at`, `updated_at`) VALUES
(1, 'dictionaries', 1, 0, '2015-04-06 08:51:32', '2015-04-06 08:51:32'),
(2, 'pages', 1, 1, '2015-04-06 08:51:32', '2015-04-06 08:51:32'),
(3, 'galleries', 1, 2, '2015-04-06 08:51:32', '2015-04-06 08:51:32'),
(4, 'seo', 1, 3, '2015-04-06 08:51:32', '2015-04-06 08:51:32'),
(5, 'catalog', 1, 4, '2015-04-06 08:51:32', '2015-04-06 08:51:32'),
(6, 'system', 1, 127, '2015-04-06 08:51:32', '2015-04-06 08:51:32'),
(7, 'news', 0, 0, '2015-04-06 08:56:11', '2015-04-06 08:56:11'),
(8, 'uploads', 1, 0, '2015-04-06 08:56:15', '2015-04-06 08:56:15');

-- --------------------------------------------------------

--
-- Структура таблицы `pages`
--

DROP TABLE IF EXISTS `pages`;
CREATE TABLE IF NOT EXISTS `pages` (
`id` int(10) unsigned NOT NULL,
  `version_of` int(10) unsigned DEFAULT NULL,
  `name` varchar(128) COLLATE utf8_unicode_ci DEFAULT NULL,
  `slug` varchar(128) COLLATE utf8_unicode_ci DEFAULT NULL,
  `sysname` varchar(128) COLLATE utf8_unicode_ci DEFAULT NULL,
  `template` varchar(128) COLLATE utf8_unicode_ci DEFAULT NULL,
  `type_id` int(10) unsigned DEFAULT NULL,
  `publication` tinyint(1) unsigned DEFAULT '1',
  `start_page` tinyint(1) unsigned DEFAULT NULL,
  `order` int(10) unsigned DEFAULT NULL,
  `settings` text COLLATE utf8_unicode_ci NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Структура таблицы `pages_blocks`
--

DROP TABLE IF EXISTS `pages_blocks`;
CREATE TABLE IF NOT EXISTS `pages_blocks` (
`id` int(10) unsigned NOT NULL,
  `page_id` int(10) unsigned DEFAULT NULL,
  `name` varchar(128) COLLATE utf8_unicode_ci DEFAULT NULL,
  `slug` varchar(128) COLLATE utf8_unicode_ci DEFAULT NULL,
  `desc` varchar(128) COLLATE utf8_unicode_ci DEFAULT NULL,
  `template` varchar(128) COLLATE utf8_unicode_ci DEFAULT NULL,
  `order` int(10) unsigned DEFAULT NULL,
  `settings` text COLLATE utf8_unicode_ci NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Структура таблицы `pages_blocks_meta`
--

DROP TABLE IF EXISTS `pages_blocks_meta`;
CREATE TABLE IF NOT EXISTS `pages_blocks_meta` (
`id` int(10) unsigned NOT NULL,
  `block_id` int(10) unsigned DEFAULT NULL,
  `name` varchar(128) COLLATE utf8_unicode_ci DEFAULT NULL,
  `content` text COLLATE utf8_unicode_ci,
  `language` varchar(16) COLLATE utf8_unicode_ci DEFAULT NULL,
  `template` varchar(128) COLLATE utf8_unicode_ci DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Структура таблицы `pages_meta`
--

DROP TABLE IF EXISTS `pages_meta`;
CREATE TABLE IF NOT EXISTS `pages_meta` (
`id` int(10) unsigned NOT NULL,
  `page_id` int(10) unsigned DEFAULT NULL,
  `language` varchar(16) COLLATE utf8_unicode_ci DEFAULT NULL,
  `template` varchar(128) COLLATE utf8_unicode_ci DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Структура таблицы `photos`
--

DROP TABLE IF EXISTS `photos`;
CREATE TABLE IF NOT EXISTS `photos` (
`id` int(10) unsigned NOT NULL,
  `name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `gallery_id` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `title` text COLLATE utf8_unicode_ci NOT NULL,
  `order` int(10) unsigned NOT NULL DEFAULT '999',
  `created_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Структура таблицы `rel_mod_gallery`
--

DROP TABLE IF EXISTS `rel_mod_gallery`;
CREATE TABLE IF NOT EXISTS `rel_mod_gallery` (
`id` int(10) unsigned NOT NULL,
  `module` varchar(16) COLLATE utf8_unicode_ci DEFAULT NULL,
  `unit_id` int(10) unsigned DEFAULT '0',
  `gallery_id` int(10) unsigned DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Структура таблицы `seo`
--

DROP TABLE IF EXISTS `seo`;
CREATE TABLE IF NOT EXISTS `seo` (
`id` int(10) unsigned NOT NULL,
  `module` varchar(32) COLLATE utf8_unicode_ci DEFAULT NULL,
  `unit_id` int(10) unsigned DEFAULT NULL,
  `language` varchar(16) COLLATE utf8_unicode_ci DEFAULT NULL,
  `title` varchar(256) COLLATE utf8_unicode_ci DEFAULT NULL,
  `description` text COLLATE utf8_unicode_ci,
  `keywords` text COLLATE utf8_unicode_ci,
  `url` varchar(256) COLLATE utf8_unicode_ci DEFAULT NULL,
  `h1` varchar(256) COLLATE utf8_unicode_ci DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Структура таблицы `sessions`
--

DROP TABLE IF EXISTS `sessions`;
CREATE TABLE IF NOT EXISTS `sessions` (
  `id` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `payload` text COLLATE utf8_unicode_ci NOT NULL,
  `last_activity` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Дамп данных таблицы `sessions`
--

INSERT INTO `sessions` (`id`, `payload`, `last_activity`) VALUES
('80b1264be73168dfa026345d79abc86a1d29660c', 'YTo2OntzOjY6Il90b2tlbiI7czo0MDoiQXVsQ0M1Y0dhQTJMV2lKWVF4VTVlUkRtZ0s0NE5wdFRHeXh2eEdjMSI7czo2OiJsb2NhbGUiO3M6MjoicnUiO3M6MjI6IlBIUERFQlVHQkFSX1NUQUNLX0RBVEEiO2E6MDp7fXM6NToiZmxhc2giO2E6Mjp7czozOiJvbGQiO2E6MDp7fXM6MzoibmV3IjthOjA6e319czozODoibG9naW5fODJlNWQyYzU2YmRkMDgxMTMxOGYwY2YwNzhiNzhiZmMiO2k6MTtzOjk6Il9zZjJfbWV0YSI7YTozOntzOjE6InUiO2k6MTQxNjM5OTU3MztzOjE6ImMiO2k6MTQxNjM5Mzg3ODtzOjE6ImwiO3M6MToiMCI7fX0=', 1428321091),
('ef55666b09924bd8d0a93c46ad1678ea42702562', 'YTo1OntzOjY6Il90b2tlbiI7czo0MDoicDViMlAwSXBaTmlrbE9uS1BqTlladEJ2d3hnQnkzRENLTGJVVzBiVCI7czo1OiJmbGFzaCI7YToyOntzOjM6Im9sZCI7YTowOnt9czozOiJuZXciO2E6MDp7fX1zOjIyOiJQSFBERUJVR0JBUl9TVEFDS19EQVRBIjthOjA6e31zOjM4OiJsb2dpbl84MmU1ZDJjNTZiZGQwODExMzE4ZjBjZjA3OGI3OGJmYyI7aToyO3M6OToiX3NmMl9tZXRhIjthOjM6e3M6MToidSI7aToxNDI4MzIxODU1O3M6MToiYyI7aToxNDI4MzIxMDk4O3M6MToibCI7czoxOiIwIjt9fQ==', 1428321855);

-- --------------------------------------------------------

--
-- Структура таблицы `settings`
--

DROP TABLE IF EXISTS `settings`;
CREATE TABLE IF NOT EXISTS `settings` (
`id` int(10) unsigned NOT NULL,
  `module` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `value` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00'
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=2 ;

--
-- Дамп данных таблицы `settings`
--

INSERT INTO `settings` (`id`, `module`, `name`, `value`, `created_at`, `updated_at`) VALUES
(1, '', 'language', 'ru', '2015-04-06 08:51:31', '2015-04-06 08:51:31');

-- --------------------------------------------------------

--
-- Структура таблицы `storages`
--

DROP TABLE IF EXISTS `storages`;
CREATE TABLE IF NOT EXISTS `storages` (
`id` int(10) unsigned NOT NULL,
  `module` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `value` text COLLATE utf8_unicode_ci NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Структура таблицы `uploads`
--

DROP TABLE IF EXISTS `uploads`;
CREATE TABLE IF NOT EXISTS `uploads` (
`id` int(10) unsigned NOT NULL,
  `path` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `original_name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `filesize` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `mimetype` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `mime1` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `mime2` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `module` varchar(32) COLLATE utf8_unicode_ci DEFAULT NULL,
  `unit_id` int(10) unsigned DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Структура таблицы `users`
--

DROP TABLE IF EXISTS `users`;
CREATE TABLE IF NOT EXISTS `users` (
`id` int(10) unsigned NOT NULL,
  `group_id` smallint(5) unsigned DEFAULT '0',
  `name` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `surname` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `email` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `active` smallint(5) unsigned DEFAULT '0',
  `password` varchar(60) COLLATE utf8_unicode_ci DEFAULT NULL,
  `photo` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `thumbnail` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `temporary_code` varchar(25) COLLATE utf8_unicode_ci DEFAULT NULL,
  `code_life` bigint(20) DEFAULT NULL,
  `remember_token` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00'
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=4 ;

--
-- Дамп данных таблицы `users`
--

INSERT INTO `users` (`id`, `group_id`, `name`, `surname`, `email`, `active`, `password`, `photo`, `thumbnail`, `temporary_code`, `code_life`, `remember_token`, `created_at`, `updated_at`) VALUES
(1, 1, 'Разработчик', '', 'developer@visokiy-bereg.ru', 1, '$2y$10$UAurmfwlnZdE3yjP1UTy8eNrelJWfW/JK3Wt.IIgS3skHMdVMyGEO', '', '', '', 0, 'mhbQLjsCPBpnW30c3ZEDDpE79bmTK3hiSrzBdXwZ1bMd4qXcWeMNTtsFq9LP', '2015-04-06 08:51:31', '2015-04-06 08:57:49'),
(2, 2, 'Администратор', '', 'admin@visokiy-bereg.ru', 1, '$2y$10$0yLAsYFE7kJEcGHW9o//f.fxQ3XmsdsuFzDEwG7pGQ7QulnW6l7Bi', '', '', '', 0, 'Eg54rQJvnsDZRijK81eaiioFyUjRfmH07pfVQ7YBuUxow5xBQoWNYF3wQDHq', '2015-04-06 08:51:31', '2015-04-06 08:59:44'),
(3, 3, 'Модератор', '', 'moder@visokiy-bereg.ru', 1, '$2y$10$lB.SWKpnHQ1vA/i98cdpUeEA4gXGEYpPdfKqNAEOPUrsLIv7SoU9m', '', '', '', 0, NULL, '2015-04-06 08:51:31', '2015-04-06 08:51:31');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `actions`
--
ALTER TABLE `actions`
 ADD PRIMARY KEY (`id`), ADD KEY `actions_group_id_index` (`group_id`), ADD KEY `actions_module_index` (`module`), ADD KEY `actions_action_index` (`action`), ADD KEY `actions_status_index` (`status`);

--
-- Indexes for table `dictionary`
--
ALTER TABLE `dictionary`
 ADD PRIMARY KEY (`id`), ADD UNIQUE KEY `dictionary_slug_unique` (`slug`), ADD KEY `dictionary_name_index` (`name`), ADD KEY `dictionary_entity_index` (`entity`), ADD KEY `dictionary_view_access_index` (`view_access`), ADD KEY `dictionary_order_index` (`order`);

--
-- Indexes for table `dictionary_fields_values`
--
ALTER TABLE `dictionary_fields_values`
 ADD PRIMARY KEY (`id`), ADD KEY `dictionary_fields_values_dicval_id_index` (`dicval_id`), ADD KEY `dictionary_fields_values_language_index` (`language`), ADD KEY `dictionary_fields_values_key_index` (`key`), ADD KEY `dictionary_fields_values_value_index` (`value`);

--
-- Indexes for table `dictionary_textfields_values`
--
ALTER TABLE `dictionary_textfields_values`
 ADD PRIMARY KEY (`id`), ADD KEY `dictionary_textfields_values_dicval_id_index` (`dicval_id`), ADD KEY `dictionary_textfields_values_language_index` (`language`), ADD KEY `dictionary_textfields_values_key_index` (`key`);

--
-- Indexes for table `dictionary_values`
--
ALTER TABLE `dictionary_values`
 ADD PRIMARY KEY (`id`), ADD KEY `dictionary_values_version_of_index` (`version_of`), ADD KEY `dictionary_values_dic_id_index` (`dic_id`), ADD KEY `dictionary_values_slug_index` (`slug`), ADD KEY `dictionary_values_order_index` (`order`), ADD KEY `dictionary_values_lft_index` (`lft`), ADD KEY `dictionary_values_rgt_index` (`rgt`);

--
-- Indexes for table `dictionary_values_meta`
--
ALTER TABLE `dictionary_values_meta`
 ADD PRIMARY KEY (`id`), ADD KEY `dictionary_values_meta_dicval_id_index` (`dicval_id`), ADD KEY `dictionary_values_meta_language_index` (`language`);

--
-- Indexes for table `dictionary_values_rel`
--
ALTER TABLE `dictionary_values_rel`
 ADD PRIMARY KEY (`dicval_parent_id`,`dicval_child_id`), ADD KEY `dictionary_values_rel_dicval_parent_id_index` (`dicval_parent_id`), ADD KEY `dictionary_values_rel_dicval_child_id_index` (`dicval_child_id`), ADD KEY `dictionary_values_rel_dicval_parent_dic_id_index` (`dicval_parent_dic_id`), ADD KEY `dictionary_values_rel_dicval_child_dic_id_index` (`dicval_child_dic_id`), ADD KEY `dictionary_values_rel_dicval_parent_field_index` (`dicval_parent_field`(255));

--
-- Indexes for table `galleries`
--
ALTER TABLE `galleries`
 ADD PRIMARY KEY (`id`);

--
-- Indexes for table `groups`
--
ALTER TABLE `groups`
 ADD PRIMARY KEY (`id`), ADD UNIQUE KEY `groups_name_unique` (`name`);

--
-- Indexes for table `modules`
--
ALTER TABLE `modules`
 ADD PRIMARY KEY (`id`);

--
-- Indexes for table `pages`
--
ALTER TABLE `pages`
 ADD PRIMARY KEY (`id`), ADD KEY `pages_version_of_index` (`version_of`), ADD KEY `pages_slug_index` (`slug`), ADD KEY `pages_type_id_index` (`type_id`), ADD KEY `pages_publication_index` (`publication`), ADD KEY `pages_start_page_index` (`start_page`), ADD KEY `pages_order_index` (`order`);

--
-- Indexes for table `pages_blocks`
--
ALTER TABLE `pages_blocks`
 ADD PRIMARY KEY (`id`), ADD KEY `pages_blocks_page_id_index` (`page_id`), ADD KEY `pages_blocks_slug_index` (`slug`), ADD KEY `pages_blocks_order_index` (`order`);

--
-- Indexes for table `pages_blocks_meta`
--
ALTER TABLE `pages_blocks_meta`
 ADD PRIMARY KEY (`id`), ADD KEY `pages_blocks_meta_block_id_index` (`block_id`), ADD KEY `pages_blocks_meta_language_index` (`language`);

--
-- Indexes for table `pages_meta`
--
ALTER TABLE `pages_meta`
 ADD PRIMARY KEY (`id`), ADD KEY `pages_meta_page_id_index` (`page_id`), ADD KEY `pages_meta_language_index` (`language`);

--
-- Indexes for table `photos`
--
ALTER TABLE `photos`
 ADD PRIMARY KEY (`id`), ADD KEY `photos_gallery_id_index` (`gallery_id`), ADD KEY `photos_order_index` (`order`);

--
-- Indexes for table `rel_mod_gallery`
--
ALTER TABLE `rel_mod_gallery`
 ADD PRIMARY KEY (`id`), ADD KEY `rel_mod_gallery_module_index` (`module`), ADD KEY `unit_id` (`module`);

--
-- Indexes for table `seo`
--
ALTER TABLE `seo`
 ADD PRIMARY KEY (`id`), ADD KEY `unit_id` (`module`), ADD KEY `seo_module_index` (`module`), ADD KEY `seo_unit_id_index` (`unit_id`), ADD KEY `seo_language_index` (`language`), ADD KEY `seo_url_index` (`url`(255));

--
-- Indexes for table `sessions`
--
ALTER TABLE `sessions`
 ADD UNIQUE KEY `sessions_id_unique` (`id`);

--
-- Indexes for table `settings`
--
ALTER TABLE `settings`
 ADD PRIMARY KEY (`id`), ADD KEY `name` (`module`), ADD KEY `settings_module_index` (`module`), ADD KEY `settings_name_index` (`name`);

--
-- Indexes for table `storages`
--
ALTER TABLE `storages`
 ADD PRIMARY KEY (`id`), ADD KEY `name` (`module`), ADD KEY `storages_module_index` (`module`), ADD KEY `storages_name_index` (`name`);

--
-- Indexes for table `uploads`
--
ALTER TABLE `uploads`
 ADD PRIMARY KEY (`id`), ADD KEY `uploads_mime1_index` (`mime1`), ADD KEY `uploads_mime2_index` (`mime2`), ADD KEY `uploads_module_index` (`module`), ADD KEY `uploads_unit_id_index` (`unit_id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
 ADD PRIMARY KEY (`id`), ADD UNIQUE KEY `users_email_unique` (`email`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `actions`
--
ALTER TABLE `actions`
MODIFY `id` int(10) unsigned NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=44;
--
-- AUTO_INCREMENT for table `dictionary`
--
ALTER TABLE `dictionary`
MODIFY `id` int(10) unsigned NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `dictionary_fields_values`
--
ALTER TABLE `dictionary_fields_values`
MODIFY `id` int(10) unsigned NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `dictionary_textfields_values`
--
ALTER TABLE `dictionary_textfields_values`
MODIFY `id` int(10) unsigned NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `dictionary_values`
--
ALTER TABLE `dictionary_values`
MODIFY `id` int(10) unsigned NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `dictionary_values_meta`
--
ALTER TABLE `dictionary_values_meta`
MODIFY `id` int(10) unsigned NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `galleries`
--
ALTER TABLE `galleries`
MODIFY `id` int(10) unsigned NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `groups`
--
ALTER TABLE `groups`
MODIFY `id` int(10) unsigned NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=4;
--
-- AUTO_INCREMENT for table `modules`
--
ALTER TABLE `modules`
MODIFY `id` int(10) unsigned NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=9;
--
-- AUTO_INCREMENT for table `pages`
--
ALTER TABLE `pages`
MODIFY `id` int(10) unsigned NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `pages_blocks`
--
ALTER TABLE `pages_blocks`
MODIFY `id` int(10) unsigned NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `pages_blocks_meta`
--
ALTER TABLE `pages_blocks_meta`
MODIFY `id` int(10) unsigned NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `pages_meta`
--
ALTER TABLE `pages_meta`
MODIFY `id` int(10) unsigned NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `photos`
--
ALTER TABLE `photos`
MODIFY `id` int(10) unsigned NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `rel_mod_gallery`
--
ALTER TABLE `rel_mod_gallery`
MODIFY `id` int(10) unsigned NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `seo`
--
ALTER TABLE `seo`
MODIFY `id` int(10) unsigned NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `settings`
--
ALTER TABLE `settings`
MODIFY `id` int(10) unsigned NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=2;
--
-- AUTO_INCREMENT for table `storages`
--
ALTER TABLE `storages`
MODIFY `id` int(10) unsigned NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `uploads`
--
ALTER TABLE `uploads`
MODIFY `id` int(10) unsigned NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
MODIFY `id` int(10) unsigned NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=4;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
