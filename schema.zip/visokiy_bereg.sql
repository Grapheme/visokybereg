-- phpMyAdmin SQL Dump
-- version 4.2.5
-- http://www.phpmyadmin.net
--
-- Хост: localhost
-- Время создания: Апр 07 2015 г., 15:00
-- Версия сервера: 5.5.25
-- Версия PHP: 5.5.9

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- База данных: `visokiy_bereg`
--

-- --------------------------------------------------------

--
-- Структура таблицы `actions`
--

DROP TABLE IF EXISTS `actions`;
CREATE TABLE IF NOT EXISTS `actions` (
`id` int(10) unsigned NOT NULL,
  `group_id` int(10) unsigned DEFAULT NULL,
  `module` varchar(32) COLLATE utf8_unicode_ci DEFAULT NULL,
  `action` varchar(32) COLLATE utf8_unicode_ci DEFAULT NULL,
  `status` int(10) unsigned NOT NULL DEFAULT '0'
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=100 ;

--
-- Дамп данных таблицы `actions`
--

INSERT INTO `actions` (`id`, `group_id`, `module`, `action`, `status`) VALUES
(35, 3, 'news', 'view', 1),
(36, 3, 'news', 'create', 1),
(37, 3, 'news', 'edit', 1),
(38, 3, 'news', 'delete', 1),
(39, 3, 'pages', 'view', 1),
(40, 3, 'pages', 'create', 1),
(41, 3, 'pages', 'edit', 1),
(42, 3, 'pages', 'delete', 1),
(43, 3, 'seo', 'edit', 1),
(79, 2, 'dictionaries', 'dicval_view', 1),
(80, 2, 'dictionaries', 'dicval_create', 1),
(81, 2, 'dictionaries', 'dicval_edit', 1),
(82, 2, 'dictionaries', 'dicval_delete', 1),
(83, 2, 'dictionaries', 'dicval_entity_view', 1),
(84, 2, 'galleries', 'create', 1),
(85, 2, 'galleries', 'edit', 1),
(86, 2, 'galleries', 'delete', 1),
(87, 2, 'pages', 'view', 1),
(88, 2, 'pages', 'create', 1),
(89, 2, 'pages', 'edit', 1),
(90, 2, 'pages', 'delete', 1),
(91, 2, 'pages', 'advanced', 1),
(92, 2, 'pages', 'page_restore', 1),
(93, 2, 'seo', 'edit', 1),
(94, 2, 'system', 'system', 1),
(95, 2, 'system', 'users', 1),
(96, 2, 'system', 'menu_editor', 1),
(97, 2, 'uploads', 'view', 1),
(98, 2, 'uploads', 'create', 1),
(99, 2, 'uploads', 'delete', 1);

-- --------------------------------------------------------

--
-- Структура таблицы `dictionary`
--

DROP TABLE IF EXISTS `dictionary`;
CREATE TABLE IF NOT EXISTS `dictionary` (
`id` int(10) unsigned NOT NULL,
  `slug` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `entity` tinyint(1) unsigned DEFAULT NULL,
  `icon_class` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `hide_slug` tinyint(1) unsigned DEFAULT NULL,
  `make_slug_from_name` tinyint(1) unsigned DEFAULT NULL,
  `name_title` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `pagination` int(10) unsigned NOT NULL DEFAULT '0',
  `view_access` smallint(5) unsigned DEFAULT NULL,
  `sort_by` varchar(64) COLLATE utf8_unicode_ci DEFAULT NULL,
  `sort_order_reverse` smallint(5) unsigned NOT NULL DEFAULT '0',
  `sortable` smallint(5) unsigned NOT NULL DEFAULT '1',
  `order` int(10) unsigned DEFAULT NULL,
  `settings` longtext COLLATE utf8_unicode_ci,
  `created_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Структура таблицы `dictionary_fields_values`
--

DROP TABLE IF EXISTS `dictionary_fields_values`;
CREATE TABLE IF NOT EXISTS `dictionary_fields_values` (
`id` int(10) unsigned NOT NULL,
  `dicval_id` int(10) unsigned DEFAULT NULL,
  `language` varchar(16) COLLATE utf8_unicode_ci DEFAULT NULL,
  `key` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `value` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Структура таблицы `dictionary_textfields_values`
--

DROP TABLE IF EXISTS `dictionary_textfields_values`;
CREATE TABLE IF NOT EXISTS `dictionary_textfields_values` (
`id` int(10) unsigned NOT NULL,
  `dicval_id` int(10) unsigned DEFAULT NULL,
  `language` varchar(16) COLLATE utf8_unicode_ci DEFAULT NULL,
  `key` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `value` longtext COLLATE utf8_unicode_ci,
  `created_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Структура таблицы `dictionary_values`
--

DROP TABLE IF EXISTS `dictionary_values`;
CREATE TABLE IF NOT EXISTS `dictionary_values` (
`id` int(10) unsigned NOT NULL,
  `version_of` int(10) unsigned DEFAULT NULL,
  `dic_id` int(10) unsigned DEFAULT NULL,
  `slug` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `order` int(10) unsigned DEFAULT NULL,
  `lft` int(10) unsigned DEFAULT NULL,
  `rgt` int(10) unsigned DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Структура таблицы `dictionary_values_meta`
--

DROP TABLE IF EXISTS `dictionary_values_meta`;
CREATE TABLE IF NOT EXISTS `dictionary_values_meta` (
`id` int(10) unsigned NOT NULL,
  `dicval_id` int(10) unsigned DEFAULT NULL,
  `language` varchar(16) COLLATE utf8_unicode_ci DEFAULT NULL,
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Структура таблицы `dictionary_values_rel`
--

DROP TABLE IF EXISTS `dictionary_values_rel`;
CREATE TABLE IF NOT EXISTS `dictionary_values_rel` (
  `dicval_parent_id` int(10) unsigned NOT NULL DEFAULT '0',
  `dicval_child_id` int(10) unsigned NOT NULL DEFAULT '0',
  `dicval_parent_dic_id` int(10) unsigned DEFAULT NULL,
  `dicval_child_dic_id` int(10) unsigned DEFAULT NULL,
  `dicval_parent_field` varchar(256) COLLATE utf8_unicode_ci DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Структура таблицы `galleries`
--

DROP TABLE IF EXISTS `galleries`;
CREATE TABLE IF NOT EXISTS `galleries` (
`id` int(10) unsigned NOT NULL,
  `name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `settings` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Структура таблицы `groups`
--

DROP TABLE IF EXISTS `groups`;
CREATE TABLE IF NOT EXISTS `groups` (
`id` int(10) unsigned NOT NULL,
  `name` varchar(20) COLLATE utf8_unicode_ci NOT NULL,
  `desc` varchar(20) COLLATE utf8_unicode_ci NOT NULL,
  `dashboard` varchar(20) COLLATE utf8_unicode_ci NOT NULL,
  `start_url` varchar(256) COLLATE utf8_unicode_ci NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00'
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=4 ;

--
-- Дамп данных таблицы `groups`
--

INSERT INTO `groups` (`id`, `name`, `desc`, `dashboard`, `start_url`, `created_at`, `updated_at`) VALUES
(1, 'developer', 'Разработчики', 'admin', '', '2015-04-06 08:51:31', '2015-04-06 08:51:31'),
(2, 'admin', 'Администраторы', 'admin', '', '2015-04-06 08:51:31', '2015-04-07 07:48:47'),
(3, 'moderator', 'Модераторы', 'admin', '', '2015-04-06 08:51:31', '2015-04-06 08:57:38');

-- --------------------------------------------------------

--
-- Структура таблицы `migrations`
--

DROP TABLE IF EXISTS `migrations`;
CREATE TABLE IF NOT EXISTS `migrations` (
  `migration` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `batch` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Дамп данных таблицы `migrations`
--

INSERT INTO `migrations` (`migration`, `batch`) VALUES
('2014_01_01_100000_create_groups_table', 1),
('2014_01_01_100010_create_users_table', 1),
('2014_01_01_100020_create_modules_table', 1),
('2014_01_01_100030_create_actions_table', 1),
('2014_01_01_100040_create_session_table', 1),
('2014_01_01_100050_create_settings_table', 1),
('2014_01_01_100051_create_storages_table', 1),
('2014_01_01_100060_create_pages_tables', 1),
('2014_01_01_100080_create_galleries_table', 1),
('2014_01_01_100090_create_photos_table', 1),
('2014_01_01_100100_create_rel_mod_gallery_table', 1),
('2014_01_01_100110_create_seo_table', 1),
('2014_07_03_161130_create_dics_tables', 1),
('2014_09_02_161130_create_uploads_tables', 1);

-- --------------------------------------------------------

--
-- Структура таблицы `modules`
--

DROP TABLE IF EXISTS `modules`;
CREATE TABLE IF NOT EXISTS `modules` (
`id` int(10) unsigned NOT NULL,
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `on` tinyint(1) NOT NULL DEFAULT '0',
  `order` tinyint(1) NOT NULL DEFAULT '0',
  `created_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00'
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=9 ;

--
-- Дамп данных таблицы `modules`
--

INSERT INTO `modules` (`id`, `name`, `on`, `order`, `created_at`, `updated_at`) VALUES
(1, 'dictionaries', 1, 0, '2015-04-06 08:51:32', '2015-04-06 08:51:32'),
(2, 'pages', 1, 1, '2015-04-06 08:51:32', '2015-04-06 08:51:32'),
(3, 'galleries', 1, 2, '2015-04-06 08:51:32', '2015-04-06 08:51:32'),
(4, 'seo', 1, 3, '2015-04-06 08:51:32', '2015-04-06 08:51:32'),
(5, 'catalog', 1, 4, '2015-04-06 08:51:32', '2015-04-06 08:51:32'),
(6, 'system', 1, 127, '2015-04-06 08:51:32', '2015-04-06 08:51:32'),
(7, 'news', 0, 0, '2015-04-06 08:56:11', '2015-04-06 08:56:11'),
(8, 'uploads', 1, 0, '2015-04-06 08:56:15', '2015-04-06 08:56:15');

-- --------------------------------------------------------

--
-- Структура таблицы `pages`
--

DROP TABLE IF EXISTS `pages`;
CREATE TABLE IF NOT EXISTS `pages` (
`id` int(10) unsigned NOT NULL,
  `version_of` int(10) unsigned DEFAULT NULL,
  `name` varchar(128) COLLATE utf8_unicode_ci DEFAULT NULL,
  `slug` varchar(128) COLLATE utf8_unicode_ci DEFAULT NULL,
  `sysname` varchar(128) COLLATE utf8_unicode_ci DEFAULT NULL,
  `template` varchar(128) COLLATE utf8_unicode_ci DEFAULT NULL,
  `type_id` int(10) unsigned DEFAULT NULL,
  `publication` tinyint(1) unsigned DEFAULT '1',
  `start_page` tinyint(1) unsigned DEFAULT NULL,
  `order` int(10) unsigned DEFAULT NULL,
  `settings` text COLLATE utf8_unicode_ci NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00'
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=106 ;

--
-- Дамп данных таблицы `pages`
--

INSERT INTO `pages` (`id`, `version_of`, `name`, `slug`, `sysname`, `template`, `type_id`, `publication`, `start_page`, `order`, `settings`, `created_at`, `updated_at`) VALUES
(1, NULL, 'Главная страница', 'glavnaya-stranica', 'index', 'index', NULL, 1, 1, NULL, '{"new_block":0}', '2015-04-06 10:57:24', '2015-04-06 11:43:32'),
(4, NULL, 'О поселке', 'o-poselke', 'about', 'about', NULL, 1, NULL, NULL, '{"new_block":0}', '2015-04-06 11:50:53', '2015-04-06 11:50:53'),
(19, NULL, 'План поселка', 'plan-poselka', 'plan', 'plan', NULL, 1, NULL, NULL, '{"new_block":0}', '2015-04-06 12:14:15', '2015-04-06 12:14:15'),
(30, NULL, 'Проекты', 'proektu', 'projects', 'projects', NULL, 1, NULL, NULL, '{"new_block":0}', '2015-04-06 12:41:28', '2015-04-06 12:41:28'),
(34, NULL, 'Строительство', 'stroitelstvo', 'building', 'building', NULL, 1, NULL, NULL, '{"new_block":0}', '2015-04-06 13:14:27', '2015-04-06 13:14:27'),
(45, NULL, '1 Этажный 67м2', '1-etazhnyj-67m2', 'project-1-page', 'project', NULL, 1, NULL, NULL, '{"new_block":0}', '2015-04-07 06:07:58', '2015-04-07 06:07:58'),
(46, NULL, '1 Этажный 75м2', '1-etazhnyj-75m2', 'project-2-page', 'project', NULL, 1, NULL, NULL, '{"new_block":0}', '2015-04-07 06:10:50', '2015-04-07 06:10:50'),
(47, NULL, '1 Этажный 89м2', '1-etazhnyj-89m2', 'project-3-page', 'project', NULL, 1, NULL, NULL, '{"new_block":0}', '2015-04-07 06:11:47', '2015-04-07 06:11:47'),
(49, NULL, '2 Этажный 138м2', '2-etazhnyj-138m2', 'project-4-page', 'project', NULL, 1, NULL, NULL, '{"new_block":0}', '2015-04-07 06:13:06', '2015-04-07 07:35:24'),
(50, NULL, '2 Этажный 141м2', '2-etazhnyj-141m2', 'project-5-page', 'project', NULL, 1, NULL, NULL, '{"new_block":0}', '2015-04-07 06:14:00', '2015-04-07 06:14:00');

-- --------------------------------------------------------

--
-- Структура таблицы `pages_blocks`
--

DROP TABLE IF EXISTS `pages_blocks`;
CREATE TABLE IF NOT EXISTS `pages_blocks` (
`id` int(10) unsigned NOT NULL,
  `page_id` int(10) unsigned DEFAULT NULL,
  `name` varchar(128) COLLATE utf8_unicode_ci DEFAULT NULL,
  `slug` varchar(128) COLLATE utf8_unicode_ci DEFAULT NULL,
  `desc` varchar(128) COLLATE utf8_unicode_ci DEFAULT NULL,
  `template` varchar(128) COLLATE utf8_unicode_ci DEFAULT NULL,
  `order` int(10) unsigned DEFAULT NULL,
  `settings` text COLLATE utf8_unicode_ci NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00'
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=703 ;

--
-- Дамп данных таблицы `pages_blocks`
--

INSERT INTO `pages_blocks` (`id`, `page_id`, `name`, `slug`, `desc`, `template`, `order`, `settings`, `created_at`, `updated_at`) VALUES
(1, 1, 'Основное описание', 'about', NULL, NULL, 0, '{"editor_state":"","system_block":0}', '2015-04-06 11:43:32', '2015-04-06 11:44:07'),
(2, 1, 'Адрес', 'address', NULL, NULL, 1, '{"editor_state":"","system_block":0}', '2015-04-06 11:43:32', '2015-04-06 11:44:17'),
(5, 4, 'Описание страницы', 'description', NULL, NULL, 0, '{"editor_state":"","system_block":0}', '2015-04-06 11:52:55', '2015-04-06 11:53:15'),
(7, 4, 'Расположение', 'location', NULL, NULL, 1, '{"editor_state":"","system_block":0}', '2015-04-06 11:54:44', '2015-04-06 11:55:01'),
(10, 4, 'Расположение текст', 'location_text', NULL, NULL, 2, '{"editor_state":"","system_block":0}', '2015-04-06 11:55:36', '2015-04-06 11:55:52'),
(17, 4, 'Образ жизни', 'lifestyle', NULL, NULL, 3, '{"editor_state":"","system_block":0}', '2015-04-06 11:58:49', '2015-04-06 11:59:19'),
(18, 4, 'Образ жизни текст', 'lifestyle_text', NULL, NULL, 4, '{"editor_state":"","system_block":0}', '2015-04-06 11:58:49', '2015-04-06 11:59:28'),
(29, 4, 'Экология', 'ecology', NULL, NULL, 5, '{"editor_state":"","system_block":0}', '2015-04-06 12:03:25', '2015-04-06 12:03:54'),
(30, 4, 'Экология текст', 'ecology_text', NULL, NULL, 6, '{"editor_state":"","system_block":0}', '2015-04-06 12:03:25', '2015-04-06 12:04:05'),
(45, 4, 'Эко.подворья', 'ecology_podvorya', NULL, NULL, 7, '{"editor_state":"","system_block":0}', '2015-04-06 12:06:42', '2015-04-06 12:06:53'),
(46, 4, 'Эко.подворья текст', 'ecology_podvorya_text', NULL, NULL, 8, '{"editor_state":"","system_block":0}', '2015-04-06 12:06:42', '2015-04-06 12:07:04'),
(83, 4, 'SEO', 'seo', NULL, NULL, 9, '', '2015-04-06 12:09:07', '2015-04-06 12:09:07'),
(84, 19, 'Основное описание', 'description', NULL, NULL, 0, '{"editor_state":"","system_block":0}', '2015-04-06 12:16:39', '2015-04-06 12:16:49'),
(86, 19, 'Площадь поселка', 'area_village', NULL, NULL, 1, '{"editor_state":"","system_block":0}', '2015-04-06 12:18:20', '2015-04-06 12:19:50'),
(89, 19, 'Таунхаусы', 'townhouses', NULL, NULL, 2, '{"editor_state":"","system_block":0}', '2015-04-06 12:19:20', '2015-04-06 12:19:31'),
(96, 19, 'Первая очередь', 'first_turn', NULL, NULL, 3, '{"editor_state":"","system_block":0}', '2015-04-06 12:28:34', '2015-04-06 12:29:53'),
(101, 19, 'Первая очередь текст', 'first_turn_text', NULL, NULL, 4, '{"editor_state":"","system_block":0}', '2015-04-06 12:28:54', '2015-04-06 12:30:04'),
(118, 34, 'Основное описание', 'description', NULL, NULL, 0, '{"editor_state":"","system_block":0}', '2015-04-06 13:16:21', '2015-04-06 13:16:38'),
(121, 34, 'Водоснабжение', 'vodosnabzhenie', NULL, NULL, 1, '{"editor_state":"","system_block":0}', '2015-04-06 13:17:29', '2015-04-06 13:43:40'),
(124, 34, 'Водоснабжение текст', 'vodosnabzhenie_text', NULL, NULL, 2, '{"editor_state":"","system_block":0}', '2015-04-06 13:17:57', '2015-04-06 13:43:57'),
(134, 34, 'Скважина', 'skvazhina', NULL, NULL, 3, '{"editor_state":"","system_block":0}', '2015-04-06 13:45:23', '2015-04-06 13:45:53'),
(139, 34, 'Водоотведение', 'vodootvedenie', NULL, NULL, 4, '{"editor_state":"","system_block":0}', '2015-04-06 13:45:40', '2015-04-06 13:46:04'),
(150, 34, 'Электроснабжение', 'elektrosnabzhenie', NULL, NULL, 5, '{"editor_state":"","system_block":0}', '2015-04-06 13:47:40', '2015-04-06 13:48:14'),
(157, 34, 'Электроснабжение текст', 'elektrosnabzhenie_text', NULL, NULL, 6, '{"editor_state":"","system_block":0}', '2015-04-06 13:48:04', '2015-04-06 13:48:22'),
(172, 34, 'Мощность на дом', 'moshhnost', NULL, NULL, 7, '{"editor_state":"","system_block":0}', '2015-04-06 13:49:24', '2015-04-06 13:49:54'),
(181, 34, 'Подстанция', 'podstanciya', NULL, NULL, 8, '{"editor_state":"","system_block":0}', '2015-04-06 13:49:43', '2015-04-06 13:50:06'),
(209, 34, 'Инд.строительство', 'individualnoe-stroitelstvo', NULL, NULL, 9, '{"editor_state":"","system_block":0}', '2015-04-06 13:52:40', '2015-04-06 13:57:40'),
(220, 34, 'Инд.строительство текст', 'individualnoe-stroitelstvo-text', NULL, NULL, 10, '{"editor_state":"","system_block":0}', '2015-04-06 13:56:31', '2015-04-06 13:57:52'),
(243, 34, 'О застройщике', 'o-zastrojshhike', NULL, NULL, 11, '{"editor_state":"","system_block":0}', '2015-04-06 13:58:57', '2015-04-06 13:59:25'),
(244, 34, 'О застройщике текст', 'o-zastrojshhike-text', NULL, NULL, 12, '{"editor_state":"","system_block":0}', '2015-04-06 13:58:57', '2015-04-06 14:01:34'),
(250, 19, 'SEO', 'seo', NULL, NULL, 5, '', '2015-04-07 05:47:18', '2015-04-07 05:47:18'),
(264, 34, 'SEO', 'seo', NULL, NULL, 13, '', '2015-04-07 05:47:32', '2015-04-07 05:47:32'),
(285, 30, 'SEO', 'seo', NULL, NULL, 0, '', '2015-04-07 05:47:51', '2015-04-07 05:47:51'),
(287, 30, '1 Этажный 67м2', 'project-1', NULL, NULL, 1, '{"editor_state":"","system_block":0}', '2015-04-07 05:49:47', '2015-04-07 05:59:48'),
(288, 30, '1 Этажный 75м2', 'project-2', NULL, NULL, 2, '{"editor_state":"","system_block":0}', '2015-04-07 05:49:47', '2015-04-07 06:00:05'),
(289, 30, '1 Этажный 89м2', 'project-3', NULL, NULL, 3, '{"editor_state":"","system_block":0}', '2015-04-07 05:49:47', '2015-04-07 06:00:24'),
(294, 30, '2 Этажный 138м2', 'project-4', NULL, NULL, 4, '{"editor_state":"","system_block":0}', '2015-04-07 05:50:33', '2015-04-07 06:01:03'),
(295, 30, '2 Этажный 141м2', 'project-5', NULL, NULL, 5, '{"editor_state":"","system_block":0}', '2015-04-07 05:50:33', '2015-04-07 06:01:19'),
(314, 45, 'Короткое описание', 'small_description', NULL, NULL, 0, '{"editor_state":"","system_block":0}', '2015-04-07 07:11:57', '2015-04-07 07:17:16'),
(317, 45, 'Цена', 'price', NULL, NULL, 1, '{"editor_state":"","system_block":0}', '2015-04-07 07:13:36', '2015-04-07 07:13:44'),
(322, 45, 'Основное изображение', 'main_image', NULL, NULL, 2, '{"editor_state":"","system_block":0}', '2015-04-07 07:15:05', '2015-04-07 07:15:18'),
(335, 45, 'Основное описание', 'description', NULL, NULL, 3, '{"editor_state":"","system_block":0}', '2015-04-07 07:18:06', '2015-04-07 07:18:26'),
(344, 45, 'Жилая площадь', 'zhilaya-ploshhad', NULL, NULL, 4, '{"editor_state":"","system_block":0}', '2015-04-07 07:20:59', '2015-04-07 07:21:26'),
(350, 45, 'Участок', 'uchastok', NULL, NULL, 5, '{"editor_state":"","system_block":0}', '2015-04-07 07:21:42', '2015-04-07 07:22:06'),
(363, 45, 'Автостоянка', 'avtostoyanka', NULL, NULL, 6, '{"editor_state":"","system_block":0}', '2015-04-07 07:22:52', '2015-04-07 07:23:13'),
(378, 45, 'План 1-го этажа', 'etazh-1', NULL, NULL, 7, '{"editor_state":"","system_block":0}', '2015-04-07 07:25:34', '2015-04-07 07:28:02'),
(387, 45, 'План 2-го этажа', 'etazh-2', NULL, NULL, 8, '', '2015-04-07 07:25:51', '2015-04-07 07:25:51'),
(444, 50, 'Короткое описание', 'small_description', NULL, NULL, 0, '', '2015-04-07 07:39:42', '2015-04-07 07:39:42'),
(445, 50, 'Цена', 'price', NULL, NULL, 1, '{"editor_state":"","system_block":0}', '2015-04-07 07:39:42', '2015-04-07 07:43:01'),
(446, 50, 'Основное изображение', 'main_image', NULL, NULL, 2, '{"editor_state":"","system_block":0}', '2015-04-07 07:39:42', '2015-04-07 07:44:18'),
(447, 50, 'Основное описание', 'description', NULL, NULL, 3, '', '2015-04-07 07:39:42', '2015-04-07 07:39:42'),
(448, 50, 'Жилая площадь', 'zhilaya-ploshhad', NULL, NULL, 4, '{"editor_state":"","system_block":0}', '2015-04-07 07:39:42', '2015-04-07 07:45:17'),
(449, 50, 'Участок', 'uchastok', NULL, NULL, 5, '{"editor_state":"","system_block":0}', '2015-04-07 07:39:42', '2015-04-07 07:45:49'),
(450, 49, 'Короткое описание', 'small_description', NULL, NULL, 0, '', '2015-04-07 07:39:43', '2015-04-07 07:39:43'),
(451, 49, 'Цена', 'price', NULL, NULL, 1, '{"editor_state":"","system_block":0}', '2015-04-07 07:39:43', '2015-04-07 07:42:54'),
(452, 49, 'Основное изображение', 'main_image', NULL, NULL, 2, '{"editor_state":"","system_block":0}', '2015-04-07 07:39:43', '2015-04-07 07:44:10'),
(453, 49, 'Основное описание', 'description', NULL, NULL, 3, '', '2015-04-07 07:39:43', '2015-04-07 07:39:43'),
(454, 49, 'Жилая площадь', 'zhilaya-ploshhad', NULL, NULL, 4, '{"editor_state":"","system_block":0}', '2015-04-07 07:39:43', '2015-04-07 07:45:12'),
(455, 49, 'Участок', 'uchastok', NULL, NULL, 5, '{"editor_state":"","system_block":0}', '2015-04-07 07:39:43', '2015-04-07 07:45:45'),
(456, 47, 'Короткое описание', 'small_description', NULL, NULL, 0, '', '2015-04-07 07:39:46', '2015-04-07 07:39:46'),
(457, 47, 'Цена', 'price', NULL, NULL, 1, '{"editor_state":"","system_block":0}', '2015-04-07 07:39:46', '2015-04-07 07:42:48'),
(458, 47, 'Основное изображение', 'main_image', NULL, NULL, 2, '{"editor_state":"","system_block":0}', '2015-04-07 07:39:46', '2015-04-07 07:44:04'),
(459, 47, 'Основное описание', 'description', NULL, NULL, 3, '', '2015-04-07 07:39:46', '2015-04-07 07:39:46'),
(460, 47, 'Жилая площадь', 'zhilaya-ploshhad', NULL, NULL, 4, '{"editor_state":"","system_block":0}', '2015-04-07 07:39:46', '2015-04-07 07:45:08'),
(461, 47, 'Участок', 'uchastok', NULL, NULL, 5, '{"editor_state":"","system_block":0}', '2015-04-07 07:39:46', '2015-04-07 07:45:40'),
(462, 46, 'Короткое описание', 'small_description', NULL, NULL, 0, '', '2015-04-07 07:39:47', '2015-04-07 07:39:47'),
(463, 46, 'Цена', 'price', NULL, NULL, 1, '{"editor_state":"","system_block":0}', '2015-04-07 07:39:48', '2015-04-07 07:42:41'),
(464, 46, 'Основное изображение', 'main_image', NULL, NULL, 2, '{"editor_state":"","system_block":0}', '2015-04-07 07:39:48', '2015-04-07 07:43:57'),
(465, 46, 'Основное описание', 'description', NULL, NULL, 3, '', '2015-04-07 07:39:48', '2015-04-07 07:39:48'),
(466, 46, 'Жилая площадь', 'zhilaya-ploshhad', NULL, NULL, 4, '{"editor_state":"","system_block":0}', '2015-04-07 07:39:48', '2015-04-07 07:45:05'),
(467, 46, 'Участок', 'uchastok', NULL, NULL, 5, '{"editor_state":"","system_block":0}', '2015-04-07 07:39:48', '2015-04-07 07:45:35'),
(474, 50, 'Автостоянка', 'avtostoyanka', NULL, NULL, 6, '{"editor_state":"","system_block":0}', '2015-04-07 07:41:43', '2015-04-07 07:46:24'),
(475, 50, 'План 1-го этажа', 'etazh-1', NULL, NULL, 7, '{"editor_state":"","system_block":0}', '2015-04-07 07:41:43', '2015-04-07 07:47:08'),
(476, 50, 'План 2-го этажа', 'etazh-2', NULL, NULL, 8, '', '2015-04-07 07:41:43', '2015-04-07 07:41:43'),
(484, 49, 'Автостоянка', 'avtostoyanka', NULL, NULL, 6, '{"editor_state":"","system_block":0}', '2015-04-07 07:41:45', '2015-04-07 07:46:22'),
(485, 49, 'План 1-го этажа', 'etazh-1', NULL, NULL, 7, '{"editor_state":"","system_block":0}', '2015-04-07 07:41:45', '2015-04-07 07:47:01'),
(486, 49, 'План 2-го этажа', 'etazh-2', NULL, NULL, 8, '', '2015-04-07 07:41:45', '2015-04-07 07:41:45'),
(494, 47, 'Автостоянка', 'avtostoyanka', NULL, NULL, 6, '{"editor_state":"","system_block":0}', '2015-04-07 07:41:48', '2015-04-07 07:46:20'),
(495, 47, 'План 1-го этажа', 'etazh-1', NULL, NULL, 7, '{"editor_state":"","system_block":0}', '2015-04-07 07:41:48', '2015-04-07 07:46:53'),
(496, 47, 'План 2-го этажа', 'etazh-2', NULL, NULL, 8, '', '2015-04-07 07:41:48', '2015-04-07 07:41:48'),
(504, 46, 'Автостоянка', 'avtostoyanka', NULL, NULL, 6, '{"editor_state":"","system_block":0}', '2015-04-07 07:41:53', '2015-04-07 07:46:18'),
(505, 46, 'План 1-го этажа', 'etazh-1', NULL, NULL, 7, '{"editor_state":"","system_block":0}', '2015-04-07 07:41:53', '2015-04-07 07:46:46'),
(506, 46, 'План 2-го этажа', 'etazh-2', NULL, NULL, 8, '', '2015-04-07 07:41:53', '2015-04-07 07:41:53');

-- --------------------------------------------------------

--
-- Структура таблицы `pages_blocks_meta`
--

DROP TABLE IF EXISTS `pages_blocks_meta`;
CREATE TABLE IF NOT EXISTS `pages_blocks_meta` (
`id` int(10) unsigned NOT NULL,
  `block_id` int(10) unsigned DEFAULT NULL,
  `name` varchar(128) COLLATE utf8_unicode_ci DEFAULT NULL,
  `content` text COLLATE utf8_unicode_ci,
  `language` varchar(16) COLLATE utf8_unicode_ci DEFAULT NULL,
  `template` varchar(128) COLLATE utf8_unicode_ci DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00'
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=520 ;

--
-- Дамп данных таблицы `pages_blocks_meta`
--

INSERT INTO `pages_blocks_meta` (`id`, `block_id`, `name`, `content`, `language`, `template`, `created_at`, `updated_at`) VALUES
(1, 1, NULL, ' Уникальный коттеджный поселок на берегу Азовского моря.<br>\r\nЖить у моря с комфортом возможно.<br>\r\nДобро пожаловать домой.', 'ru', NULL, '2015-04-06 11:44:07', '2015-04-06 11:44:07'),
(2, 2, NULL, 'Ростовская область, с. Вареновка,<br> берег Азовcкого моря', 'ru', NULL, '2015-04-06 11:44:17', '2015-04-06 11:44:17'),
(5, 5, NULL, 'Коттеджный поселок «Высокий берег» – прекрасный выбор<br>\r\n                    для тех, кто ценит тишину и единение с природой в сочетании<br>\r\n                    с комфортом и безопасностью.', 'ru', NULL, '2015-04-06 11:53:15', '2015-04-06 11:53:15'),
(7, 7, NULL, 'Расположение', 'ru', NULL, '2015-04-06 11:55:01', '2015-04-06 11:55:01'),
(10, 10, NULL, '<p>\r\n                        Коттеджный поселок &laquo;Высокий берег&raquo;&nbsp;&mdash; это\r\n                        загородный жилой комплекс, который воплотил в&nbsp;себя идею\r\n                        современного загородного дома для постоянного проживания\r\n                        с&nbsp;высоким уровнем комфорта, а&nbsp;также развитой\r\n                        инфраструктурой. Он&nbsp;расположен\r\n                        в&nbsp;<nobr>Юго-Восточной</nobr> части Ростовской области\r\n                    Неклиновского района, в&nbsp;30&nbsp;минутах езды от&nbsp;Ростова,\r\n                    а&nbsp;так&nbsp;же 10&nbsp;минутах от&nbsp;Таганрога. Кроме того,\r\n                    здесь находится станция электропоезда.\r\n                    </p>\r\n                    <p>Руководство  района готово оказывать всестороннюю поддержку проекта.</p>\r\n                    <p>ПЛОЩАДЬ ПОСЕЛКА<br><strong>41 га</strong></p>', 'ru', NULL, '2015-04-06 11:55:53', '2015-04-06 11:55:53'),
(17, 17, NULL, 'Новый образ жизни', 'ru', NULL, '2015-04-06 11:59:19', '2015-04-06 11:59:19'),
(18, 18, NULL, '<p>\r\n                        Дом в&nbsp;коттеджном поселке &laquo;Высокий\r\n                        берег&raquo;&nbsp;&mdash; это новый образ жизни, альтернатива\r\n                        проживания в&nbsp;типовом многоэтажном здании, он&nbsp;подходит для\r\n                        молодых семей, стремящихся жить и&nbsp;воспитывать детей\r\n                        в&nbsp;окружении природы, на&nbsp;своей земле, вдали от&nbsp;смога,\r\n                        пыли и&nbsp;вечных пробок; а&nbsp;также пожилого населения, которое\r\n                        сможет отдохнуть от&nbsp;бешеного ритма городской суеты.\r\n                    </p>\r\n                    <p>\r\n                        &laquo;Высокий берег&raquo;&nbsp;&mdash; новый, современный жилой\r\n                        комплекс, который объединяет достоинства загородного коттеджного\r\n                        поселка с&nbsp;городской инфраструктурой.\r\n                    </p>', 'ru', NULL, '2015-04-06 11:59:28', '2015-04-06 12:00:12'),
(29, 29, NULL, 'Экология', 'ru', NULL, '2015-04-06 12:03:54', '2015-04-06 12:03:54'),
(30, 30, NULL, '<p>\r\n                        О&nbsp;благоприятной экологической обстановке в&nbsp;поселке\r\n                        свидетельствует строительство в&nbsp;прямой видимости от&nbsp;него\r\n                        современного тепличного комплекса. Перед его строительством долго\r\n                        изучалась экология района. Непосредственно рядом с&nbsp;поселком\r\n                        в&nbsp;Таганрогский залив вподает небольшая река Самбечка. Начато\r\n                        оформление документов на&nbsp;очистку и&nbsp;обустройство пляжной\r\n                        линии протяженностью 900&nbsp;метров.\r\n                    </p>\r\n                    <p>\r\n                        В&nbsp;ближайшее время на&nbsp;смежном участке будет начато\r\n                        строительство комплекса для занятий скайсерфингом. С&nbsp;высокого\r\n                        берега (12&nbsp;метров) открывается отличный вид на&nbsp;город\r\n                        Таганрог и&nbsp;Таганрогский залив.\r\n                    </p>', 'ru', NULL, '2015-04-06 12:04:05', '2015-04-06 12:04:05'),
(45, 45, NULL, 'Экологические подворья', 'ru', NULL, '2015-04-06 12:06:53', '2015-04-06 12:06:53'),
(46, 46, NULL, '<p>\r\n                        На территории поселка будут заложены экологические\r\n                        подворья — особые зоны с виноградниками. Для этого\r\n                        мы привлечем одних из лучших виноградарей юга России. Ваша\r\n                        собственная усадьба с элитными виноградниками может стать\r\n                        солидным источником доходов. Даже если у Вас нет опыта,\r\n                        мы подберем отличных специалистов, которые будут с особой\r\n                        заботой ухаживать за Вашим хозяйством. Вы только\r\n                        представьте, как будете угощать друзей вином, сделанным собственными\r\n                        руками! Это — не просто увлечениее, это новый образ\r\n                        жизни.\r\n                    </p>', 'ru', NULL, '2015-04-06 12:07:04', '2015-04-06 12:07:29'),
(83, 84, NULL, '<p>\r\n                        Коттеджный поселок &laquo;Высокий берег&raquo; расположен\r\n                        в&nbsp;30&nbsp;минутной езде от&nbsp;Ростова, а&nbsp;так&nbsp;же\r\n                        10&nbsp;минутах от&nbsp;Таганрога. Рядом&nbsp;&mdash; станция\r\n                        электропоезда. На&nbsp;территории комплекса будут расположены\r\n                        высокотехнологичные дома, спортивные площадки, супермаркет,\r\n                        собственный пляж, а&nbsp;так&nbsp;же <nobr>яхт-клуб</nobr>.\r\n                    В&nbsp;шаговой доступности находится детский сад и&nbsp;школа.\r\n                    </p>\r\n                    <p>\r\n                        Планом предусмотрено возведение таунхаусов (первая\r\n                        очередь&nbsp;&mdash; 2015 год), а&nbsp;также отведены земли под\r\n                        индивидуальное строительство.\r\n                    </p>', 'ru', NULL, '2015-04-06 12:16:49', '2015-04-06 12:16:49'),
(86, 89, NULL, '67&mdash;141 м<sup>2</sup>', 'ru', NULL, '2015-04-06 12:19:31', '2015-04-06 12:19:31'),
(87, 86, NULL, '41 га', 'ru', NULL, '2015-04-06 12:19:50', '2015-04-06 12:19:50'),
(100, 96, NULL, 'Первая очередь', 'ru', NULL, '2015-04-06 12:29:54', '2015-04-06 12:29:54'),
(101, 101, NULL, '<p>\r\n              В течении 2015 года будет возведена первая очередь с большим выбором проектов.\r\n              Это одноэтажные и двухэтажные таунхаусы с различной жилой площадью в едином архитектурном стиле.\r\n            </p>', 'ru', NULL, '2015-04-06 12:30:04', '2015-04-06 12:30:04'),
(112, 118, NULL, '<p>\r\n                        Важнейшим принципом строительства загородного жилого комплекса\r\n                        &laquo;Высокий берег&raquo; является обеспечение качественного\r\n                        уровня проживания. Все дома в&nbsp;коттеджном поселке строятся\r\n                        по&nbsp;современной технологии. В&nbsp;то&nbsp;же время покупателю\r\n                        предлагается выбор проектов&nbsp;&mdash; одноэтажные\r\n                        и&nbsp;двухэтажные таунхаусы с&nbsp;различной жилой площадью\r\n                        в&nbsp;едином архитектурном стиле.\r\n                    </p>\r\n                    <p>\r\n                        Кроме этого, весь поселок отличает единый, красивый ландшафт.\r\n                        &laquo;Высокий берег&raquo;&nbsp;&mdash; это уникальный проект,\r\n                        который отличают общий генплан, организованная застройка, единый\r\n                        архитектурный стиль, благоустроенная территория\r\n                        и&nbsp;энергоэффективные технологии.\r\n                    </p>', 'ru', NULL, '2015-04-06 13:16:38', '2015-04-06 13:16:38'),
(116, 121, NULL, 'Водоснабжение', 'ru', NULL, '2015-04-06 13:43:40', '2015-04-06 13:43:40'),
(117, 124, NULL, ' <p>\r\n                        Водоснабжение дома, а&nbsp;также водоотведение являются важнейшими\r\n                        аспектами комфортабельности загородного жилья. Вопрос водоснабжения\r\n                        таунхауса или котеджа мы&nbsp;решаем при помощи глубинной скважины\r\n                        с&nbsp;погружным насосом. В&nbsp;данном районе вода пригодная для\r\n                        использования находится на&nbsp;глубине от&nbsp;35\r\n                        до&nbsp;40&nbsp;метров. В&nbsp;самом доме можно будет установить\r\n                        систему водоподготовки с&nbsp;насосной станцией.\r\n                    </p>\r\n                    <p>\r\n                        На&nbsp;участке установлена автономная канализация\r\n                    <nobr>ЭКО-М-1</nobr>, которая прекрасно обслуживает семью до&nbsp;пяти\r\n                    человек. Обслуживание такого очистного сооружения требует минимальных\r\n                    усилий.\r\n                    </p>', 'ru', NULL, '2015-04-06 13:43:57', '2015-04-06 13:43:57'),
(130, 134, NULL, 'На каждом участке', 'ru', NULL, '2015-04-06 13:45:53', '2015-04-06 13:45:53'),
(131, 139, NULL, 'Автономная канализация\r\n', 'ru', NULL, '2015-04-06 13:46:04', '2015-04-06 13:46:04'),
(147, 150, NULL, 'Электроснабжение', 'ru', NULL, '2015-04-06 13:48:14', '2015-04-06 13:48:14'),
(148, 157, NULL, '<p>\r\n                        Для энергоснабжения поселка предусмотрено строительства на&nbsp;его\r\n                        территории трансформаторной подстанции мощностью 630 кВт.\r\n                        На&nbsp;каждый дом выделено от&nbsp;10 до&nbsp;15 кВт мощности при\r\n                        входном напряжении 380 вольт.\r\n                    </p>', 'ru', NULL, '2015-04-06 13:48:22', '2015-04-06 13:48:22'),
(170, 172, NULL, '10-15 кВт', 'ru', NULL, '2015-04-06 13:49:54', '2015-04-06 13:49:54'),
(171, 181, NULL, '630 кВт', 'ru', NULL, '2015-04-06 13:50:06', '2015-04-06 13:50:06'),
(208, 209, NULL, 'Индивидуальное строительство', 'ru', NULL, '2015-04-06 13:57:40', '2015-04-06 13:57:40'),
(209, 220, NULL, '<p>\r\n                        Помимо выбора из&nbsp;готовых проектов, можно остановиться\r\n                        и&nbsp;на&nbsp;варианте с&nbsp;индивидуальным проектированием\r\n                        и&nbsp;строительством на&nbsp;свободном участке любого размера.\r\n                        Специалисты работают с&nbsp;заказчиком по&nbsp;его плану. Вас\r\n                        внимательно выслушают, учтут все Ваши пожелания, идеи\r\n                        и&nbsp;требования и&nbsp;создадут неповторимый проект, который\r\n                        органично впишется по&nbsp;стилю в&nbsp;общий план поселка.\r\n                    </p>\r\n                    <p>\r\n                        Фантазия заказчика ограничена только площадью выбранного участка,\r\n                        а&nbsp;также общим архитектурным стилем поселка.\r\n                    </p>', 'ru', NULL, '2015-04-06 13:57:52', '2015-04-06 13:57:52'),
(232, 243, NULL, 'О застройщике', 'ru', NULL, '2015-04-06 13:59:25', '2015-04-06 13:59:25'),
(233, 244, NULL, '<p>\r\n                        Компания <nobr>ООО &laquo;ТехноСтрой&raquo;</nobr> занимается\r\n                    строительством домов по&nbsp;технологии &laquo;несъемной опалубки\r\n                    из&nbsp;пенополистирола&raquo;. Имея многолетний опыт работы,\r\n                    мы&nbsp;обладаем необходимыми знаниями и&nbsp;навыками для решения\r\n                    задач любой сложности. Оказываем услуги по&nbsp;разработке\r\n                    <nobr>дизайн-проектов</nobr> домов и&nbsp;коттеджей.\r\n                    </p>\r\n                    <p>\r\n                        Также в&nbsp;спектре компании внутренние и&nbsp;наружные отделочные\r\n                        работы любой сложности, комплексное благоустройство участка,\r\n                        строительство бассейнов и&nbsp;водоемов, электромонтажные,\r\n                        сантехнические и&nbsp;озеленительные работы. Доступные цены\r\n                        на&nbsp;все наши услуги. Мы&nbsp;можем построить дом\r\n                        и&nbsp;благоустроить участок в&nbsp;соответствии со&nbsp;всеми\r\n                        вашими пожеланиями и&nbsp;предложить свои оригинальные решения.\r\n                    </p>\r\n                    <p><br></p>\r\n                    <p>\r\n                        г. Ростов-на-Дону,<br>\r\n                        ул. Белорусская, 199, офис 4\r\n                    </p>\r\n                    <p><strong>+7 (918) 544-50-54</strong></p>\r\n                    <p>\r\n                        <strong>Директор</strong><br>\r\n                        Побенжиев Александр\r\n\r\n                    </p>', 'ru', NULL, '2015-04-06 14:01:34', '2015-04-06 14:01:34'),
(270, 287, NULL, '<div style="background-image:url(''http://dummyimage.com/497x305/'');" class="visual"></div>\r\n                <div class="info">\r\n                    <div class="small">67м<sup>2</sup></div>\r\n                    <div class="big">\r\n                        <div class="wrapper">\r\n                            <h2>Одноэтажный таунхаус, 67м<sup>2</sup></h2>\r\n                            <div class="info">от 35 000 руб. за м<sup>2</sup></div>\r\n                        </div>\r\n                    </div>\r\n                </div>\r\n            ', 'ru', NULL, '2015-04-07 05:59:48', '2015-04-07 06:03:37'),
(271, 288, NULL, '<div style="background-image:url(''http://dummyimage.com/497x305/'');" class="visual"></div>\r\n                <div class="info">\r\n                    <div class="small">75м<sup>2</sup></div>\r\n                    <div class="big">\r\n                        <div class="wrapper">\r\n                            <h2>Одноэтажный таунхаус, 75м<sup>2</sup></h2>\r\n                            <div class="info">от 35 000 руб. за м<sup>2</sup></div>\r\n                        </div>\r\n                    </div>\r\n                </div>', 'ru', NULL, '2015-04-07 06:00:05', '2015-04-07 06:04:01'),
(272, 289, NULL, '<div style="background-image:url(''http://dummyimage.com/497x305/'');" class="visual"></div>\r\n                <div class="info">\r\n                    <div class="small">89м<sup>2</sup></div>\r\n                    <div class="big">\r\n                        <div class="wrapper">\r\n                            <h2>Одноэтажный таунхаус, 89м<sup>2</sup></h2>\r\n                            <div class="info">от 35 000 руб. за м<sup>2</sup></div>\r\n                        </div>\r\n                    </div>\r\n                </div>', 'ru', NULL, '2015-04-07 06:00:24', '2015-04-07 06:04:13'),
(273, 294, NULL, '<div style="background-image:url(''http://dummyimage.com/497x305/'');" class="visual"></div>\r\n                <div class="info">\r\n                    <div class="small">138м<sup>2</sup></div>\r\n                    <div class="big">\r\n                        <div class="wrapper">\r\n                            <h2>Двухэтажный таунхаус, 138м<sup>2</sup></h2>\r\n                            <div class="info">от 35 000 руб. за м<sup>2</sup></div>\r\n                        </div>\r\n                    </div>\r\n                </div>', 'ru', NULL, '2015-04-07 06:01:03', '2015-04-07 06:04:26'),
(274, 295, NULL, '<div style="background-image:url(''http://dummyimage.com/497x305/'');" class="visual"></div>\r\n                <div class="info">\r\n                    <div class="small">141м<sup>2</sup></div>\r\n                    <div class="big">\r\n                        <div class="wrapper">\r\n                            <h2>Двухэтажный таунхаус, 141м<sup>2</sup></h2>\r\n                            <div class="info">от 35 000 руб. за м<sup>2</sup></div>\r\n                        </div>\r\n                    </div>\r\n                </div>', 'ru', NULL, '2015-04-07 06:01:20', '2015-04-07 06:04:37'),
(285, 314, NULL, ' <p>\r\n                    <nobr>1-этажный</nobr> проект дома сочетает в&nbsp;себе компактность\r\n                    и&nbsp;удобство. Несмотря на&nbsp;небольшую площадь, все комнаты\r\n                    просторные и&nbsp;уютные, а&nbsp;поддерживать в&nbsp;порядок\r\n                    в&nbsp;таком доме не&nbsp;сложно. Основное преимущество\r\n                    <nobr>1-этажного</nobr> дома&nbsp;&mdash; быстрый доступ\r\n                    ко&nbsp;всем помещениям, а&nbsp;также безопасность в&nbsp;виду\r\n                    отсутствия лестниц, что особенно важно и&nbsp;актуально для семей\r\n                    с&nbsp;детьми или пожилых людей.\r\n                    </p>', 'ru', NULL, '2015-04-07 07:12:11', '2015-04-07 07:12:11'),
(288, 317, NULL, 'от 35 000 руб./м<sup>2</sup>', 'ru', NULL, '2015-04-07 07:13:45', '2015-04-07 07:13:45'),
(293, 322, NULL, '<div style="background-image: url(''/theme/dist/images/visual-house.jpg'')" class="img"></div>\r\n                    <div class="marks">\r\n                        <div style="top:50px; left: 150px;" class="mark"><a class="plus"></a><a class="cross"></a>\r\n                            <div class="wrapper">\r\n                                <div class="text">\r\n                                    <p>\r\n                                        Благоустройство территории\r\n                                        включает в себя озеленение\r\n                                        и мощение\r\n                                    </p>\r\n                                </div>\r\n                            </div>\r\n                        </div>\r\n                        <div style="top:200px; left: 300px;" class="mark"><a class="plus"></a><a class="cross"></a>\r\n                            <div class="wrapper">\r\n                                <div class="text">\r\n                                    <p>\r\n                                        Благоустройство территории\r\n                                        включает в себя озеленение\r\n                                        и мощение\r\n                                    </p>\r\n                                </div>\r\n                            </div>\r\n                        </div>\r\n                    </div>', 'ru', NULL, '2015-04-07 07:15:18', '2015-04-07 07:16:18'),
(306, 335, NULL, '<p>Строительство и&nbsp;оснащение осуществляется с&nbsp;использованием\r\n                        последних технологий в&nbsp;данной сфере. Покупая таунхаус,\r\n                        Вы&nbsp;получаете в&nbsp;собственность земельный участок. При\r\n                        строительстве дома используется газоблок, известный своими\r\n                        энергосберегающими свойствами при небольших затратах ресурсов,\r\n                        а&nbsp;для облицовки&nbsp;&mdash; кирпич, кроме того, предусмотрен\r\n                        каменный цоколь. Крыша дома покрывается мягкой кровлей. Водоснабжение\r\n                        осуществляется через индивидуальную скважину, поэтому\r\n                        Вы&nbsp;не&nbsp;будете зависеть от&nbsp;городских коммуникаций.\r\n                        В&nbsp;доме будет установлен электрокотел или индукционный котел,\r\n                        который будет поддерживать необходимую температуру воздуха в&nbsp;доме\r\n                        в&nbsp;любое время года. К&nbsp;моменту сдачи проекта\r\n                        в&nbsp;эксплуатацию будет осуществлена разводка электричества\r\n                        по&nbsp;дому (ввод от&nbsp;10 кВт). На&nbsp;участке установлена\r\n                        автономная канализация <nobr>ЭКО-М-1</nobr>, которая прекрасно\r\n                    обслуживает семью до&nbsp;пяти человек. Обслуживание такого очистного\r\n                    сооружения требует минимальных усилий. Дом будет полностью готов для\r\n                    чистовой отделки, поэтому Вы&nbsp;сможете сразу приступить к&nbsp;тому,\r\n                    что придать ему Ваш неповторимый уют и&nbsp;оформление.</p>\r\n\r\n                    <p>Также предусмотрена автостоянка и&nbsp;<nobr>мини-генератор</nobr>\r\n                    на&nbsp;веранде, что дает Вам неоспоримый дополнительный комфорт. Территория\r\n                    всего земельного участка благоустроена: устанавливается наружное освещение,\r\n                    обеспечен комфортный подъезд к&nbsp;дому. Участок огорожен забором.\r\n                    В&nbsp;поселке есть вся необходимая благоустроенная инфраструктура для\r\n                    комфортного проживания. Поэтому о&nbsp;безопасности можно\r\n                    не&nbsp;беспокоиться.</p>', 'ru', NULL, '2015-04-07 07:18:26', '2015-04-07 07:18:26'),
(315, 344, NULL, '67,0 м<sup>2</sup>', 'ru', NULL, '2015-04-07 07:21:26', '2015-04-07 07:21:26'),
(321, 350, NULL, 'от 2 соток', 'ru', NULL, '2015-04-07 07:22:07', '2015-04-07 07:22:07'),
(334, 363, NULL, 'для 1 автомобиля', 'ru', NULL, '2015-04-07 07:23:13', '2015-04-07 07:23:13'),
(363, 378, NULL, ' <div class="text">\r\n                    <div class="project-visual-wrapper">\r\n                        <img src="/theme/dist/images/visual-detail-project.png">\r\n                    </div>\r\n                </div>\r\n                <div class="side">\r\n<div class="unit">\r\n                        <div class="head">\r\n                            <img src="/theme/dist/images/ico-digit-1.png" class="ico">\r\n                            <div class="title">Этаж</div>\r\n                        </div>\r\n                    </div>\r\n                    <div class="unit">\r\n                        <a href="javascript:void(0)" class="download-file">\r\n                            <img src="/theme/dist/images/ico-pdf.png" class="ico">\r\n                            <div class="info">\r\n                                <div class="filename">Генеральный план.pdf</div>\r\n                                <div class="size">12мб</div>\r\n                            </div>\r\n                        </a>\r\n                    </div>\r\n</div>', 'ru', NULL, '2015-04-07 07:28:02', '2015-04-07 07:33:22'),
(412, 463, NULL, 'от 35 000 руб./м<sup>2</sup>', 'ru', NULL, '2015-04-07 07:42:41', '2015-04-07 07:42:41'),
(413, 457, NULL, 'от 35 000 руб./м<sup>2</sup>', 'ru', NULL, '2015-04-07 07:42:48', '2015-04-07 07:42:48'),
(414, 451, NULL, 'от 35 000 руб./м<sup>2</sup>', 'ru', NULL, '2015-04-07 07:42:55', '2015-04-07 07:42:55'),
(415, 445, NULL, 'от 35 000 руб./м<sup>2</sup>', 'ru', NULL, '2015-04-07 07:43:01', '2015-04-07 07:43:01'),
(428, 464, NULL, '<div style="background-image: url(''/theme/dist/images/visual-house.jpg'')" class="img"></div>\r\n                    <div class="marks">\r\n                        <div style="top:50px; left: 150px;" class="mark"><a class="plus"></a><a class="cross"></a>\r\n                            <div class="wrapper">\r\n                                <div class="text">\r\n                                    <p>\r\n                                        Благоустройство территории\r\n                                        включает в себя озеленение\r\n                                        и мощение\r\n                                    </p>\r\n                                </div>\r\n                            </div>\r\n                        </div>\r\n                        <div style="top:200px; left: 300px;" class="mark"><a class="plus"></a><a class="cross"></a>\r\n                            <div class="wrapper">\r\n                                <div class="text">\r\n                                    <p>\r\n                                        Благоустройство территории\r\n                                        включает в себя озеленение\r\n                                        и мощение\r\n                                    </p>\r\n                                </div>\r\n                            </div>\r\n                        </div>\r\n                    </div>', 'ru', NULL, '2015-04-07 07:43:57', '2015-04-07 07:43:57'),
(429, 458, NULL, '<div style="background-image: url(''/theme/dist/images/visual-house.jpg'')" class="img"></div>\r\n                    <div class="marks">\r\n                        <div style="top:50px; left: 150px;" class="mark"><a class="plus"></a><a class="cross"></a>\r\n                            <div class="wrapper">\r\n                                <div class="text">\r\n                                    <p>\r\n                                        Благоустройство территории\r\n                                        включает в себя озеленение\r\n                                        и мощение\r\n                                    </p>\r\n                                </div>\r\n                            </div>\r\n                        </div>\r\n                        <div style="top:200px; left: 300px;" class="mark"><a class="plus"></a><a class="cross"></a>\r\n                            <div class="wrapper">\r\n                                <div class="text">\r\n                                    <p>\r\n                                        Благоустройство территории\r\n                                        включает в себя озеленение\r\n                                        и мощение\r\n                                    </p>\r\n                                </div>\r\n                            </div>\r\n                        </div>\r\n                    </div>', 'ru', NULL, '2015-04-07 07:44:04', '2015-04-07 07:44:04'),
(430, 452, NULL, '<div style="background-image: url(''/theme/dist/images/visual-house.jpg'')" class="img"></div>\r\n                    <div class="marks">\r\n                        <div style="top:50px; left: 150px;" class="mark"><a class="plus"></a><a class="cross"></a>\r\n                            <div class="wrapper">\r\n                                <div class="text">\r\n                                    <p>\r\n                                        Благоустройство территории\r\n                                        включает в себя озеленение\r\n                                        и мощение\r\n                                    </p>\r\n                                </div>\r\n                            </div>\r\n                        </div>\r\n                        <div style="top:200px; left: 300px;" class="mark"><a class="plus"></a><a class="cross"></a>\r\n                            <div class="wrapper">\r\n                                <div class="text">\r\n                                    <p>\r\n                                        Благоустройство территории\r\n                                        включает в себя озеленение\r\n                                        и мощение\r\n                                    </p>\r\n                                </div>\r\n                            </div>\r\n                        </div>\r\n                    </div>', 'ru', NULL, '2015-04-07 07:44:10', '2015-04-07 07:44:10'),
(431, 446, NULL, '<div style="background-image: url(''/theme/dist/images/visual-house.jpg'')" class="img"></div>\r\n                    <div class="marks">\r\n                        <div style="top:50px; left: 150px;" class="mark"><a class="plus"></a><a class="cross"></a>\r\n                            <div class="wrapper">\r\n                                <div class="text">\r\n                                    <p>\r\n                                        Благоустройство территории\r\n                                        включает в себя озеленение\r\n                                        и мощение\r\n                                    </p>\r\n                                </div>\r\n                            </div>\r\n                        </div>\r\n                        <div style="top:200px; left: 300px;" class="mark"><a class="plus"></a><a class="cross"></a>\r\n                            <div class="wrapper">\r\n                                <div class="text">\r\n                                    <p>\r\n                                        Благоустройство территории\r\n                                        включает в себя озеленение\r\n                                        и мощение\r\n                                    </p>\r\n                                </div>\r\n                            </div>\r\n                        </div>\r\n                    </div>', 'ru', NULL, '2015-04-07 07:44:18', '2015-04-07 07:44:18'),
(440, 466, NULL, '67,0 м<sup>2</sup>', 'ru', NULL, '2015-04-07 07:45:05', '2015-04-07 07:45:05'),
(441, 460, NULL, '67,0 м<sup>2</sup>', 'ru', NULL, '2015-04-07 07:45:08', '2015-04-07 07:45:08'),
(442, 454, NULL, '67,0 м<sup>2</sup>', 'ru', NULL, '2015-04-07 07:45:12', '2015-04-07 07:45:12'),
(443, 448, NULL, '67,0 м<sup>2</sup>', 'ru', NULL, '2015-04-07 07:45:17', '2015-04-07 07:45:17'),
(444, 467, NULL, 'от 2 соток', 'ru', NULL, '2015-04-07 07:45:35', '2015-04-07 07:45:35'),
(445, 461, NULL, 'от 2 соток', 'ru', NULL, '2015-04-07 07:45:41', '2015-04-07 07:45:41'),
(446, 455, NULL, 'от 2 соток', 'ru', NULL, '2015-04-07 07:45:45', '2015-04-07 07:45:45'),
(447, 449, NULL, 'от 2 соток', 'ru', NULL, '2015-04-07 07:45:49', '2015-04-07 07:45:49'),
(448, 504, NULL, 'для 1 автомобиля', 'ru', NULL, '2015-04-07 07:46:18', '2015-04-07 07:46:18'),
(449, 494, NULL, 'для 1 автомобиля', 'ru', NULL, '2015-04-07 07:46:20', '2015-04-07 07:46:20'),
(450, 484, NULL, 'для 1 автомобиля', 'ru', NULL, '2015-04-07 07:46:22', '2015-04-07 07:46:22'),
(451, 474, NULL, 'для 1 автомобиля', 'ru', NULL, '2015-04-07 07:46:24', '2015-04-07 07:46:24'),
(452, 505, NULL, ' <div class="text">\r\n                    <div class="project-visual-wrapper">\r\n                        <img src="/theme/dist/images/visual-detail-project.png">\r\n                    </div>\r\n                </div>\r\n                <div class="side">\r\n<div class="unit">\r\n                        <div class="head">\r\n                            <img src="/theme/dist/images/ico-digit-1.png" class="ico">\r\n                            <div class="title">Этаж</div>\r\n                        </div>\r\n                    </div>\r\n                    <div class="unit">\r\n                        <a href="javascript:void(0)" class="download-file">\r\n                            <img src="/theme/dist/images/ico-pdf.png" class="ico">\r\n                            <div class="info">\r\n                                <div class="filename">Генеральный план.pdf</div>\r\n                                <div class="size">12мб</div>\r\n                            </div>\r\n                        </a>\r\n                    </div>\r\n</div>', 'ru', NULL, '2015-04-07 07:46:46', '2015-04-07 07:46:46'),
(453, 495, NULL, ' <div class="text">\r\n                    <div class="project-visual-wrapper">\r\n                        <img src="/theme/dist/images/visual-detail-project.png">\r\n                    </div>\r\n                </div>\r\n                <div class="side">\r\n<div class="unit">\r\n                        <div class="head">\r\n                            <img src="/theme/dist/images/ico-digit-1.png" class="ico">\r\n                            <div class="title">Этаж</div>\r\n                        </div>\r\n                    </div>\r\n                    <div class="unit">\r\n                        <a href="javascript:void(0)" class="download-file">\r\n                            <img src="/theme/dist/images/ico-pdf.png" class="ico">\r\n                            <div class="info">\r\n                                <div class="filename">Генеральный план.pdf</div>\r\n                                <div class="size">12мб</div>\r\n                            </div>\r\n                        </a>\r\n                    </div>\r\n</div>', 'ru', NULL, '2015-04-07 07:46:53', '2015-04-07 07:46:53'),
(454, 485, NULL, ' <div class="text">\r\n                    <div class="project-visual-wrapper">\r\n                        <img src="/theme/dist/images/visual-detail-project.png">\r\n                    </div>\r\n                </div>\r\n                <div class="side">\r\n<div class="unit">\r\n                        <div class="head">\r\n                            <img src="/theme/dist/images/ico-digit-1.png" class="ico">\r\n                            <div class="title">Этаж</div>\r\n                        </div>\r\n                    </div>\r\n                    <div class="unit">\r\n                        <a href="javascript:void(0)" class="download-file">\r\n                            <img src="/theme/dist/images/ico-pdf.png" class="ico">\r\n                            <div class="info">\r\n                                <div class="filename">Генеральный план.pdf</div>\r\n                                <div class="size">12мб</div>\r\n                            </div>\r\n                        </a>\r\n                    </div>\r\n</div>', 'ru', NULL, '2015-04-07 07:47:01', '2015-04-07 07:47:01'),
(455, 475, NULL, ' <div class="text">\r\n                    <div class="project-visual-wrapper">\r\n                        <img src="/theme/dist/images/visual-detail-project.png">\r\n                    </div>\r\n                </div>\r\n                <div class="side">\r\n<div class="unit">\r\n                        <div class="head">\r\n                            <img src="/theme/dist/images/ico-digit-1.png" class="ico">\r\n                            <div class="title">Этаж</div>\r\n                        </div>\r\n                    </div>\r\n                    <div class="unit">\r\n                        <a href="javascript:void(0)" class="download-file">\r\n                            <img src="/theme/dist/images/ico-pdf.png" class="ico">\r\n                            <div class="info">\r\n                                <div class="filename">Генеральный план.pdf</div>\r\n                                <div class="size">12мб</div>\r\n                            </div>\r\n                        </a>\r\n                    </div>\r\n</div>', 'ru', NULL, '2015-04-07 07:47:08', '2015-04-07 07:47:08');

-- --------------------------------------------------------

--
-- Структура таблицы `pages_meta`
--

DROP TABLE IF EXISTS `pages_meta`;
CREATE TABLE IF NOT EXISTS `pages_meta` (
`id` int(10) unsigned NOT NULL,
  `page_id` int(10) unsigned DEFAULT NULL,
  `language` varchar(16) COLLATE utf8_unicode_ci DEFAULT NULL,
  `template` varchar(128) COLLATE utf8_unicode_ci DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00'
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=106 ;

--
-- Дамп данных таблицы `pages_meta`
--

INSERT INTO `pages_meta` (`id`, `page_id`, `language`, `template`, `created_at`, `updated_at`) VALUES
(1, 1, 'ru', NULL, '2015-04-06 10:57:24', '2015-04-06 10:57:24'),
(4, 4, 'ru', NULL, '2015-04-06 11:50:53', '2015-04-06 11:50:53'),
(19, 19, 'ru', NULL, '2015-04-06 12:14:15', '2015-04-06 12:14:15'),
(30, 30, 'ru', NULL, '2015-04-06 12:41:28', '2015-04-06 12:41:28'),
(34, 34, 'ru', NULL, '2015-04-06 13:14:27', '2015-04-06 13:14:27'),
(45, 45, 'ru', NULL, '2015-04-07 06:07:58', '2015-04-07 06:07:58'),
(46, 46, 'ru', NULL, '2015-04-07 06:10:50', '2015-04-07 06:10:50'),
(47, 47, 'ru', NULL, '2015-04-07 06:11:47', '2015-04-07 06:11:47'),
(49, 49, 'ru', NULL, '2015-04-07 06:13:06', '2015-04-07 06:13:06'),
(50, 50, 'ru', NULL, '2015-04-07 06:14:00', '2015-04-07 06:14:00');

-- --------------------------------------------------------

--
-- Структура таблицы `photos`
--

DROP TABLE IF EXISTS `photos`;
CREATE TABLE IF NOT EXISTS `photos` (
`id` int(10) unsigned NOT NULL,
  `name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `gallery_id` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `title` text COLLATE utf8_unicode_ci NOT NULL,
  `order` int(10) unsigned NOT NULL DEFAULT '999',
  `created_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Структура таблицы `rel_mod_gallery`
--

DROP TABLE IF EXISTS `rel_mod_gallery`;
CREATE TABLE IF NOT EXISTS `rel_mod_gallery` (
`id` int(10) unsigned NOT NULL,
  `module` varchar(16) COLLATE utf8_unicode_ci DEFAULT NULL,
  `unit_id` int(10) unsigned DEFAULT '0',
  `gallery_id` int(10) unsigned DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Структура таблицы `seo`
--

DROP TABLE IF EXISTS `seo`;
CREATE TABLE IF NOT EXISTS `seo` (
`id` int(10) unsigned NOT NULL,
  `module` varchar(32) COLLATE utf8_unicode_ci DEFAULT NULL,
  `unit_id` int(10) unsigned DEFAULT NULL,
  `language` varchar(16) COLLATE utf8_unicode_ci DEFAULT NULL,
  `title` varchar(256) COLLATE utf8_unicode_ci DEFAULT NULL,
  `description` text COLLATE utf8_unicode_ci,
  `keywords` text COLLATE utf8_unicode_ci,
  `url` varchar(256) COLLATE utf8_unicode_ci DEFAULT NULL,
  `h1` varchar(256) COLLATE utf8_unicode_ci DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00'
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=106 ;

--
-- Дамп данных таблицы `seo`
--

INSERT INTO `seo` (`id`, `module`, `unit_id`, `language`, `title`, `description`, `keywords`, `url`, `h1`, `created_at`, `updated_at`) VALUES
(1, 'Page', 1, 'ru', 'Главная страница', '', '', NULL, 'Высокий берег', '2015-04-06 10:57:24', '2015-04-06 11:44:46'),
(4, 'Page', 4, 'ru', 'О поселке', '', '', NULL, 'О поселке', '2015-04-06 11:50:53', '2015-04-06 11:52:24'),
(19, 'Page', 19, 'ru', 'План поселка', '', '', NULL, 'План поселка', '2015-04-06 12:14:15', '2015-04-06 12:14:48'),
(30, 'Page', 30, 'ru', 'Проекты', '', '', NULL, 'Проекты таунхаусов', '2015-04-06 12:41:28', '2015-04-06 13:07:40'),
(34, 'Page', 34, 'ru', 'Строительство', '', '', NULL, 'Строительство', '2015-04-06 13:14:27', '2015-04-06 13:14:27'),
(45, 'Page', 45, 'ru', '1 Этажный 67м2', '', '', NULL, 'Одноэтажный таунхаус, 67м<sup>2</sup>', '2015-04-07 06:07:58', '2015-04-07 06:07:58'),
(46, 'Page', 46, 'ru', '1 Этажный 75м2', '', '', NULL, 'Одноэтажный таунхаус, 75м<sup>2</sup>', '2015-04-07 06:10:50', '2015-04-07 06:10:50'),
(47, 'Page', 47, 'ru', '1 Этажный 89м2', '', '', NULL, 'Одноэтажный таунхаус, 89м<sup>2</sup>', '2015-04-07 06:11:47', '2015-04-07 06:11:47'),
(49, 'Page', 49, 'ru', '2 Этажный 138м2', '', '', NULL, 'Двухэтажный таунхаус, 138м<sup>2</sup>', '2015-04-07 06:13:06', '2015-04-07 06:13:06'),
(50, 'Page', 50, 'ru', '2 Этажный 141м2', '', '', NULL, 'Двухэтажный таунхаус, 141м<sup>2</sup>', '2015-04-07 06:14:00', '2015-04-07 06:14:01');

-- --------------------------------------------------------

--
-- Структура таблицы `sessions`
--

DROP TABLE IF EXISTS `sessions`;
CREATE TABLE IF NOT EXISTS `sessions` (
  `id` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `payload` text COLLATE utf8_unicode_ci NOT NULL,
  `last_activity` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Дамп данных таблицы `sessions`
--

INSERT INTO `sessions` (`id`, `payload`, `last_activity`) VALUES
('9a212cfa86389fb11bda9ea04e04a04c1650aad7', 'YTo0OntzOjY6Il90b2tlbiI7czo0MDoiOGg3VlVOdFJjT0l0T1l6OHBuZUloVXBlbHp0N2hmV3h3RVBLQXh0WiI7czo1OiJmbGFzaCI7YToyOntzOjM6Im9sZCI7YTowOnt9czozOiJuZXciO2E6MDp7fX1zOjM4OiJsb2dpbl84MmU1ZDJjNTZiZGQwODExMzE4ZjBjZjA3OGI3OGJmYyI7aToyO3M6OToiX3NmMl9tZXRhIjthOjM6e3M6MToidSI7aToxNDI4NDA0MTUyO3M6MToiYyI7aToxNDI4Mzk0ODU5O3M6MToibCI7czoxOiIwIjt9fQ==', 1428404153);

-- --------------------------------------------------------

--
-- Структура таблицы `settings`
--

DROP TABLE IF EXISTS `settings`;
CREATE TABLE IF NOT EXISTS `settings` (
`id` int(10) unsigned NOT NULL,
  `module` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `value` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00'
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=2 ;

--
-- Дамп данных таблицы `settings`
--

INSERT INTO `settings` (`id`, `module`, `name`, `value`, `created_at`, `updated_at`) VALUES
(1, '', 'language', 'ru', '2015-04-06 08:51:31', '2015-04-06 08:51:31');

-- --------------------------------------------------------

--
-- Структура таблицы `storages`
--

DROP TABLE IF EXISTS `storages`;
CREATE TABLE IF NOT EXISTS `storages` (
`id` int(10) unsigned NOT NULL,
  `module` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `value` text COLLATE utf8_unicode_ci NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00'
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=5 ;

--
-- Дамп данных таблицы `storages`
--

INSERT INTO `storages` (`id`, `module`, `name`, `value`, `created_at`, `updated_at`) VALUES
(1, 'menu', 'main_menu', '{"title":"\\u0413\\u043b\\u0430\\u0432\\u043d\\u043e\\u0435 \\u043c\\u0435\\u043d\\u044e","nesting_level":"5","container":"<ul class=\\"main-menu\\">%elements%<\\/ul>","element_container":"<li%attr%>%element%%children%<\\/li>","element":"<a href=\\"%url%\\"%attr%>%text%<\\/a>","active_class":"active","items":{"1":{"text":"\\u041e \\u043f\\u043e\\u0441\\u0435\\u043b\\u043a\\u0435","title":"","type":"page","page_id":"4","id":"1","active_regexp":""},"2":{"text":"\\u041f\\u043b\\u0430\\u043d \\u043f\\u043e\\u0441\\u0435\\u043b\\u043a\\u0430","title":"","type":"page","page_id":"19","id":"2","active_regexp":""},"3":{"text":"\\u041f\\u0440\\u043e\\u0435\\u043a\\u0442\\u044b","title":"","type":"page","page_id":"30","id":"3","active_regexp":""},"4":{"text":"\\u0421\\u0442\\u0440\\u043e\\u0438\\u0442\\u0435\\u043b\\u044c\\u0441\\u0442\\u0432\\u043e","title":"","type":"page","page_id":"34","id":"4","active_regexp":""}},"order":"[{\\"id\\":1},{\\"id\\":2},{\\"id\\":3},{\\"id\\":4}]"}', '2015-04-07 06:23:16', '2015-04-07 06:24:56'),
(2, 'menu_placement', 'menu_placement', '{"main_menu":"main_menu","1_etazhnye_menu":"1_etazhnye_menu","2_etazhnye_menu":"2_etazhnye_menu"}', '2015-04-07 06:23:16', '2015-04-07 07:00:44'),
(3, 'menu', '1_etazhnye_menu', '{"title":"\\u041c\\u0435\\u043d\\u044e \\u043f\\u0440\\u043e\\u0435\\u043a\\u0442\\u043e\\u0432, \\u043e\\u0434\\u043d\\u043e\\u044d\\u0442\\u0430\\u0436\\u043d\\u044b\\u0435","nesting_level":"1","container":"<ul class=\\"unit\\">%elements%<\\/ul>","element_container":"<li>%element%<\\/li>","element":"<a href=\\"%url%\\"%attr%>%text%<\\/a>","active_class":"active","order":"[{\\"id\\":1},{\\"id\\":2},{\\"id\\":3}]","items":{"1":{"text":"67 \\u043c<sup>2<\\/sup>","title":"","type":"page","page_id":"45","id":"1","active_regexp":""},"2":{"text":"75 \\u043c<sup>2<\\/sup>","title":"","type":"page","page_id":"46","id":"2","active_regexp":""},"3":{"text":"89 \\u043c<sup>2<\\/sup>","title":"","type":"page","page_id":"47","id":"3","active_regexp":""}}}', '2015-04-07 06:28:33', '2015-04-07 07:06:56'),
(4, 'menu', '2_etazhnye_menu', '{"title":"\\u041c\\u0435\\u043d\\u044e \\u043f\\u0440\\u043e\\u0435\\u043a\\u0442\\u043e\\u0432, \\u0434\\u0432\\u0443\\u0445\\u044d\\u0442\\u0430\\u0436\\u043d\\u044b\\u0435","nesting_level":"1","container":"<ul class=\\"unit\\">%elements%<\\/ul>","element_container":"<li>%element%<\\/li>","element":"<a href=\\"%url%\\"%attr%>%text%<\\/a>","active_class":"active","items":{"1":{"text":"138 \\u043c<sup>2<\\/sup>","title":"","type":"page","page_id":"49","id":"1","active_regexp":""},"2":{"text":"141 \\u043c<sup>2<\\/sup>","title":"","type":"page","page_id":"50","id":"2","active_regexp":""}},"order":"[{\\"id\\":1},{\\"id\\":2}]"}', '2015-04-07 06:31:25', '2015-04-07 07:07:48');

-- --------------------------------------------------------

--
-- Структура таблицы `uploads`
--

DROP TABLE IF EXISTS `uploads`;
CREATE TABLE IF NOT EXISTS `uploads` (
`id` int(10) unsigned NOT NULL,
  `path` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `original_name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `filesize` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `mimetype` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `mime1` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `mime2` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `module` varchar(32) COLLATE utf8_unicode_ci DEFAULT NULL,
  `unit_id` int(10) unsigned DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00'
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=2 ;

-- --------------------------------------------------------

--
-- Структура таблицы `users`
--

DROP TABLE IF EXISTS `users`;
CREATE TABLE IF NOT EXISTS `users` (
`id` int(10) unsigned NOT NULL,
  `group_id` smallint(5) unsigned DEFAULT '0',
  `name` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `surname` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `email` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `active` smallint(5) unsigned DEFAULT '0',
  `password` varchar(60) COLLATE utf8_unicode_ci DEFAULT NULL,
  `photo` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `thumbnail` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `temporary_code` varchar(25) COLLATE utf8_unicode_ci DEFAULT NULL,
  `code_life` bigint(20) DEFAULT NULL,
  `remember_token` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00'
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=4 ;

--
-- Дамп данных таблицы `users`
--

INSERT INTO `users` (`id`, `group_id`, `name`, `surname`, `email`, `active`, `password`, `photo`, `thumbnail`, `temporary_code`, `code_life`, `remember_token`, `created_at`, `updated_at`) VALUES
(1, 1, 'Разработчик', '', 'developer@visokiy-bereg.ru', 1, '$2y$10$UAurmfwlnZdE3yjP1UTy8eNrelJWfW/JK3Wt.IIgS3skHMdVMyGEO', '', '', '', 0, 'xC0rnfjI8CVfAegbesK8Jr9VSsAuTWRSJ02NpFSqlISTA1GzAVQT2vb8Vmjc', '2015-04-06 08:51:31', '2015-04-07 07:48:54'),
(2, 2, 'Администратор', '', 'admin@visokiy-bereg.ru', 1, '$2y$10$0yLAsYFE7kJEcGHW9o//f.fxQ3XmsdsuFzDEwG7pGQ7QulnW6l7Bi', '', '', '', 0, 'xIWKJqyVQOo7aZ29yHg8p2Ls394TwtA3ybZGp6fAx6WqPxBXzqk1BLBcwq7I', '2015-04-06 08:51:31', '2015-04-07 07:47:58'),
(3, 3, 'Модератор', '', 'moder@visokiy-bereg.ru', 1, '$2y$10$lB.SWKpnHQ1vA/i98cdpUeEA4gXGEYpPdfKqNAEOPUrsLIv7SoU9m', '', '', '', 0, NULL, '2015-04-06 08:51:31', '2015-04-06 08:51:31');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `actions`
--
ALTER TABLE `actions`
 ADD PRIMARY KEY (`id`), ADD KEY `actions_group_id_index` (`group_id`), ADD KEY `actions_module_index` (`module`), ADD KEY `actions_action_index` (`action`), ADD KEY `actions_status_index` (`status`);

--
-- Indexes for table `dictionary`
--
ALTER TABLE `dictionary`
 ADD PRIMARY KEY (`id`), ADD UNIQUE KEY `dictionary_slug_unique` (`slug`), ADD KEY `dictionary_name_index` (`name`), ADD KEY `dictionary_entity_index` (`entity`), ADD KEY `dictionary_view_access_index` (`view_access`), ADD KEY `dictionary_order_index` (`order`);

--
-- Indexes for table `dictionary_fields_values`
--
ALTER TABLE `dictionary_fields_values`
 ADD PRIMARY KEY (`id`), ADD KEY `dictionary_fields_values_dicval_id_index` (`dicval_id`), ADD KEY `dictionary_fields_values_language_index` (`language`), ADD KEY `dictionary_fields_values_key_index` (`key`), ADD KEY `dictionary_fields_values_value_index` (`value`);

--
-- Indexes for table `dictionary_textfields_values`
--
ALTER TABLE `dictionary_textfields_values`
 ADD PRIMARY KEY (`id`), ADD KEY `dictionary_textfields_values_dicval_id_index` (`dicval_id`), ADD KEY `dictionary_textfields_values_language_index` (`language`), ADD KEY `dictionary_textfields_values_key_index` (`key`);

--
-- Indexes for table `dictionary_values`
--
ALTER TABLE `dictionary_values`
 ADD PRIMARY KEY (`id`), ADD KEY `dictionary_values_version_of_index` (`version_of`), ADD KEY `dictionary_values_dic_id_index` (`dic_id`), ADD KEY `dictionary_values_slug_index` (`slug`), ADD KEY `dictionary_values_order_index` (`order`), ADD KEY `dictionary_values_lft_index` (`lft`), ADD KEY `dictionary_values_rgt_index` (`rgt`);

--
-- Indexes for table `dictionary_values_meta`
--
ALTER TABLE `dictionary_values_meta`
 ADD PRIMARY KEY (`id`), ADD KEY `dictionary_values_meta_dicval_id_index` (`dicval_id`), ADD KEY `dictionary_values_meta_language_index` (`language`);

--
-- Indexes for table `dictionary_values_rel`
--
ALTER TABLE `dictionary_values_rel`
 ADD PRIMARY KEY (`dicval_parent_id`,`dicval_child_id`), ADD KEY `dictionary_values_rel_dicval_parent_id_index` (`dicval_parent_id`), ADD KEY `dictionary_values_rel_dicval_child_id_index` (`dicval_child_id`), ADD KEY `dictionary_values_rel_dicval_parent_dic_id_index` (`dicval_parent_dic_id`), ADD KEY `dictionary_values_rel_dicval_child_dic_id_index` (`dicval_child_dic_id`), ADD KEY `dictionary_values_rel_dicval_parent_field_index` (`dicval_parent_field`(255));

--
-- Indexes for table `galleries`
--
ALTER TABLE `galleries`
 ADD PRIMARY KEY (`id`);

--
-- Indexes for table `groups`
--
ALTER TABLE `groups`
 ADD PRIMARY KEY (`id`), ADD UNIQUE KEY `groups_name_unique` (`name`);

--
-- Indexes for table `modules`
--
ALTER TABLE `modules`
 ADD PRIMARY KEY (`id`);

--
-- Indexes for table `pages`
--
ALTER TABLE `pages`
 ADD PRIMARY KEY (`id`), ADD KEY `pages_version_of_index` (`version_of`), ADD KEY `pages_slug_index` (`slug`), ADD KEY `pages_type_id_index` (`type_id`), ADD KEY `pages_publication_index` (`publication`), ADD KEY `pages_start_page_index` (`start_page`), ADD KEY `pages_order_index` (`order`);

--
-- Indexes for table `pages_blocks`
--
ALTER TABLE `pages_blocks`
 ADD PRIMARY KEY (`id`), ADD KEY `pages_blocks_page_id_index` (`page_id`), ADD KEY `pages_blocks_slug_index` (`slug`), ADD KEY `pages_blocks_order_index` (`order`);

--
-- Indexes for table `pages_blocks_meta`
--
ALTER TABLE `pages_blocks_meta`
 ADD PRIMARY KEY (`id`), ADD KEY `pages_blocks_meta_block_id_index` (`block_id`), ADD KEY `pages_blocks_meta_language_index` (`language`);

--
-- Indexes for table `pages_meta`
--
ALTER TABLE `pages_meta`
 ADD PRIMARY KEY (`id`), ADD KEY `pages_meta_page_id_index` (`page_id`), ADD KEY `pages_meta_language_index` (`language`);

--
-- Indexes for table `photos`
--
ALTER TABLE `photos`
 ADD PRIMARY KEY (`id`), ADD KEY `photos_gallery_id_index` (`gallery_id`), ADD KEY `photos_order_index` (`order`);

--
-- Indexes for table `rel_mod_gallery`
--
ALTER TABLE `rel_mod_gallery`
 ADD PRIMARY KEY (`id`), ADD KEY `rel_mod_gallery_module_index` (`module`), ADD KEY `unit_id` (`module`);

--
-- Indexes for table `seo`
--
ALTER TABLE `seo`
 ADD PRIMARY KEY (`id`), ADD KEY `unit_id` (`module`), ADD KEY `seo_module_index` (`module`), ADD KEY `seo_unit_id_index` (`unit_id`), ADD KEY `seo_language_index` (`language`), ADD KEY `seo_url_index` (`url`(255));

--
-- Indexes for table `sessions`
--
ALTER TABLE `sessions`
 ADD UNIQUE KEY `sessions_id_unique` (`id`);

--
-- Indexes for table `settings`
--
ALTER TABLE `settings`
 ADD PRIMARY KEY (`id`), ADD KEY `name` (`module`), ADD KEY `settings_module_index` (`module`), ADD KEY `settings_name_index` (`name`);

--
-- Indexes for table `storages`
--
ALTER TABLE `storages`
 ADD PRIMARY KEY (`id`), ADD KEY `name` (`module`), ADD KEY `storages_module_index` (`module`), ADD KEY `storages_name_index` (`name`);

--
-- Indexes for table `uploads`
--
ALTER TABLE `uploads`
 ADD PRIMARY KEY (`id`), ADD KEY `uploads_mime1_index` (`mime1`), ADD KEY `uploads_mime2_index` (`mime2`), ADD KEY `uploads_module_index` (`module`), ADD KEY `uploads_unit_id_index` (`unit_id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
 ADD PRIMARY KEY (`id`), ADD UNIQUE KEY `users_email_unique` (`email`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `actions`
--
ALTER TABLE `actions`
MODIFY `id` int(10) unsigned NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=100;
--
-- AUTO_INCREMENT for table `dictionary`
--
ALTER TABLE `dictionary`
MODIFY `id` int(10) unsigned NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `dictionary_fields_values`
--
ALTER TABLE `dictionary_fields_values`
MODIFY `id` int(10) unsigned NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `dictionary_textfields_values`
--
ALTER TABLE `dictionary_textfields_values`
MODIFY `id` int(10) unsigned NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `dictionary_values`
--
ALTER TABLE `dictionary_values`
MODIFY `id` int(10) unsigned NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `dictionary_values_meta`
--
ALTER TABLE `dictionary_values_meta`
MODIFY `id` int(10) unsigned NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `galleries`
--
ALTER TABLE `galleries`
MODIFY `id` int(10) unsigned NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `groups`
--
ALTER TABLE `groups`
MODIFY `id` int(10) unsigned NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=4;
--
-- AUTO_INCREMENT for table `modules`
--
ALTER TABLE `modules`
MODIFY `id` int(10) unsigned NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=9;
--
-- AUTO_INCREMENT for table `pages`
--
ALTER TABLE `pages`
MODIFY `id` int(10) unsigned NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=106;
--
-- AUTO_INCREMENT for table `pages_blocks`
--
ALTER TABLE `pages_blocks`
MODIFY `id` int(10) unsigned NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=703;
--
-- AUTO_INCREMENT for table `pages_blocks_meta`
--
ALTER TABLE `pages_blocks_meta`
MODIFY `id` int(10) unsigned NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=520;
--
-- AUTO_INCREMENT for table `pages_meta`
--
ALTER TABLE `pages_meta`
MODIFY `id` int(10) unsigned NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=106;
--
-- AUTO_INCREMENT for table `photos`
--
ALTER TABLE `photos`
MODIFY `id` int(10) unsigned NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `rel_mod_gallery`
--
ALTER TABLE `rel_mod_gallery`
MODIFY `id` int(10) unsigned NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `seo`
--
ALTER TABLE `seo`
MODIFY `id` int(10) unsigned NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=106;
--
-- AUTO_INCREMENT for table `settings`
--
ALTER TABLE `settings`
MODIFY `id` int(10) unsigned NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=2;
--
-- AUTO_INCREMENT for table `storages`
--
ALTER TABLE `storages`
MODIFY `id` int(10) unsigned NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=5;
--
-- AUTO_INCREMENT for table `uploads`
--
ALTER TABLE `uploads`
MODIFY `id` int(10) unsigned NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=2;
--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
MODIFY `id` int(10) unsigned NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=4;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
